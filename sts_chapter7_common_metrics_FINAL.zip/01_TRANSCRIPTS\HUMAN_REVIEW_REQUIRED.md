# HUMAN_REVIEW_REQUIRED.md

The source transcripts in `source_ground_truth_review.csv` are **ASR consensus transcripts**
(3 independent passes: faster-whisper large-v3-turbo / medium / small), NOT human
ground truth. Most tokens are agreed by all three models; the items below are the
**only** disputed segments, exported as short clips in `HUMAN_REVIEW/`.

**Required listening: 6 clips, ~16 s total.**

| # | clip | segment | disagreement | proposed (used for WER) |
|---|---|---|---|---|
| 1 | `hist__B_jahr_1972-1970-1901__9.4-11.4s.wav` | "Euler wurde ___ dieses Wissen" | turbo `1972`, medium `1970`, small `1901` (3-way split; small also hallucinated "sitzig" here) | `1972` [UNRESOLVED] |
| 2 | `hist__A_die-das-spezifische__4.0-6.0s.wav` | "verwenden wir ___ spezifische Technik" | turbo+medium `die`, small `das` | `die` |
| 3 | `hist__C_uebertragen__12.8-15.0s.wav` | "dieses Wissen ___ und er hat uns" | turbo+medium `übertragen`, small `übertagen` | `übertragen` |
| 4 | `hist__D_blah-blah__16.2-19.4s.wav` | "Sachen wie ___ und ___ gegeben" | turbo+small `Blah`, medium `Bla` (×2) | `Blah` |
| 5 | `prepared__A_diese-seiten-geraet-hat__4.4-7.0s.wav` | "oder ___ Seiten ___ hat" | "die/diese": turbo `die`, medium+small `diese`; **all three hear `gerät` but PageRank context suggests `gerankt` — semantic check** | `diese Seiten gerät hat` |
| 6 | `prepared__B_zu-reihen-rein__13.0-17.4s.wav` | "um Seiten zu ___ und ein bisschen" | turbo `reihen`, medium+small `rein`; German verb for ranking would be `reihen` | `rein` |

## Sensitivity of WER to human decisions

The prepared-source reference contains 33 words; the hist reference 31. If the human
resolves any disputed token differently from the proposal above, WER shifts by
**at most ±1/33 (0.030) per token** for the affected source (and only for outputs
whose ASR hypothesis contains that exact token). The `[UNRESOLVED]` year token is
the only 3-way split; every WER row in `content_metrics_FINAL.csv` and every
CAMPPlus row is re-computable with `06_REPRODUCIBILITY/scripts/`.

## What is NOT in question

- `test01` transcript: all three models agree verbatim — no listening required.
- All other tokens of `hist` and `prepared`: 3-of-3 agreement.
- The ASR repetition artifact at the end of the prepared source (small pass only,
  `01_TRANSCRIPTS/ambiguity_report.json`) is a model artifact, not source content:
  the project's own `CONFIG_MANIFEST.txt` (matched_test, line 24) documents the
  prepared clip as ending at "...übertrieben kitschig".