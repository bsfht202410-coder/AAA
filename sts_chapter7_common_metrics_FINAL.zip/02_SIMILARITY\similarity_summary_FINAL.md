# similarity_summary_FINAL.md

CAMPPlus (funasr cn_common, 192-d) common protocol. Target centroid = normalized mean of 10 unique target recordings (deduplicated; see target_reference_set_FINAL.csv).

Leave-one-out genuine-target baseline: n=10, mean=0.9469, std=0.0196, min=0.9202, max=0.9743
(No human-recognition threshold is derived from these values.)

Source-to-target baseline (3 sources vs centroid):
- hist  0.8802
- test01 0.9187
- prepared 0.8544
