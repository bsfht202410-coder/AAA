# HUMAN_REVIEW_TASKS.md

Tasks for the author's listening review. Play each clip below (files are also in
`01_TRANSCRIPTS/HUMAN_REVIEW/`) and answer the question. Fill the `response` column
and update `source_ground_truth_review.csv` accordingly, then re-run
`06_REPRODUCIBILITY/scripts/wer_cer_final.py` to refresh the WER tables.

| # | File | Timestamp (in source) | Question | Options | Response |
|---|---|---|---|---|---|
| 1 | `hist__B_jahr_1972-1970-1901__9.4-11.4s.wav` | 9.98–10.82 s | Which number does the author say after "Euler wurde"? | 1972 / 1970 / 1901 / other | |
| 2 | `hist__A_die-das-spezifische__4.0-6.0s.wav` | 4.70–4.92 s | "…verwenden wir ___ spezifische Technik…" — "die" or "das"? | die / das | |
| 3 | `hist__C_uebertragen__12.8-15.0s.wav` | 13.36–14.26 s | "…dieses Wissen ___ und er hat uns…" — "übertragen" or "übertagen"? | übertragen / übertagen | |
| 4 | `hist__D_blah-blah__16.2-19.4s.wav` | 16.78–18.70 s | "…Sachen wie ___ und ___ gegeben." — "Blah" or "Bla"? | Blah / Bla | |
| 5 | `prepared__A_diese-seiten-geraet-hat__4.4-7.0s.wav` | 4.96–6.48 s | (a) "die" or "diese" Seiten? (b) What verb: all ASR models hear "gerät hat" but the PageRank context suggests "gerankt hat"? | (a) die/diese (b) gerät / gerankt / other | |
| 6 | `prepared__B_zu-reihen-rein__13.0-17.4s.wav` | 13.52–16.96 s | "…um Seiten zu ___ und ein bisschen…" — "reihen" or "rein"? | reihen / rein | |

## Optional listening (no metric impact)

- `prepared__A...` — also confirms whether the source really ends at
  "...übertrieben kitschig" (the small ASR pass hallucinated a sentence repetition;
  `CONFIG_MANIFEST.txt` agrees with the clip ending).