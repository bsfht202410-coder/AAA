# content_analysis_FINAL.md

Content preservation of every conversion output, measured as WER/CER against the
**verified** source transcripts (`01_TRANSCRIPTS/source_ground_truth_review.csv`,
consensus of 3 ASR passes). Raw WER is the primary metric; `delta_*` columns vs the
per-source ASR baseline are provided for context only and are NOT subtracted.

## Table

| source | system | WER | CER | S/D/I | ref words | delta_WER | delta_CER |
|---|---|---|---|---|---|---|---|
| hist | SOURCE (ASR baseline) | 0.000 | 0.000 | 0/0/0 | 31 | — | — |
| hist | RVC GermanLecturerRVC | 0.097 | 0.021 | 3/0/0 | 31 | +0.097 | +0.021 |
| hist | Seed-VC 1.0_100_0.7 | 0.097 | 0.021 | 3/0/0 | 31 | +0.097 | +0.021 |
| hist | Seed-VC 1.0_64_1.5 | 0.065 | 0.011 | 2/0/0 | 31 | +0.065 | +0.011 |
| test01 | SOURCE (ASR baseline) | 0.000 | 0.000 | 0/0/0 | 24 | — | — |
| test01 | RVC GermanLecturerRVC | 0.167 | 0.052 | 2/0/2 | 24 | +0.167 | +0.052 |
| prepared | SOURCE (ASR baseline) | 0.061 | 0.019 | 2/0/0 | 33 | — | — |
| prepared | RVC_Audit8 harvest p0 | 0.061 | 0.028 | 2/0/0 | 33 | +0.000 | +0.009 |
| prepared | RVC_Audit8 harvest p2 | 0.061 | 0.033 | 2/0/0 | 33 | +0.000 | +0.014 |
| prepared | RVC_Audit8 rmvpe p0 | 0.061 | 0.023 | 2/0/0 | 33 | +0.000 | +0.004 |
| prepared | RVC_Audit8 rmvpe p2 | 0.061 | 0.023 | 2/0/0 | 33 | +0.000 | +0.004 |
| prepared | Seed-VC 1.0_30_0.7 baseline | 0.818 | 0.558 | 19/4/4 | 33 | +0.758 | +0.539 |

## Reading

- **prepared — RVC_Audit8 (all 4 configs):** WER 0.061, identical to the source's
  own ASR baseline (delta +0.000). All four outputs say "diese Seiten ... gereiht
  hat" (RVC even moved "die"→"diese" toward the verified reference) and misrender
  the final verb differently per config ("treiben" / "primen" / "reimen"). Relative
  to the verified transcript, RVC_Audit8's prepared outputs are **ASR-indistinguishable
  in WER from the source itself**.
- **prepared — Seed-VC baseline:** WER 0.818 (19 subs, 4 dels, 4 ins of 33 words) —
  the content is largely destroyed ("Ausbringungsgungle seine Seiten ..."). The
  previous package's claim that Seed-VC preserved content is NOT supported.
- **hist — Seed-VC variants:** 64-step/t=1.5 (0.065) is the best content score of
  the whole evaluation (2 subs: "Blah"→"Bla" twice); the 100-step variant (0.097)
  adds a third sub ("die"→"das"). Both are plausible content-preserving results.
- **hist — RVC:** 0.097 (3 subs: "Sachen"→"Drachen", "Blah"→"Bla" ×2).
- **test01 — RVC:** 0.167 (2 subs + 2 ins; the well-known "auf dem Well" artifact
  and a doubled clause), despite 3-of-3-verified reference.
- **test01 was the only source with a verbatim-agreed transcript**, so its numbers
  are the least ambiguous of the set.

## Caveats

- References are ASR consensus, not human ground truth (6 disputed tokens pending
  the author's listening; see `01_TRANSCRIPTS/HUMAN_REVIEW_REQUIRED.md`). Each
  disputed token shifts WER by ≤1/33–1/31 if resolved differently.
- Case- and punctuation-normalized (German umlauts → ae/oe/ue).
- The two byte-identical Seed-VC copies are excluded from this table by design
  (see `03_PROVENANCE/seedvc_output_provenance.md`).