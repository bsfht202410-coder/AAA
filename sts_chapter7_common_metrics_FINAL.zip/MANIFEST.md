# MANIFEST — sts_chapter7_common_metrics_FINAL.zip

Corrected and finalized common-metrics evaluation for Chapter 7 (RVC vs Seed-VC
voice conversion toward the German lecturer). Supersedes
`sts_chapter7_common_metrics.zip` and `sts_chapter7_evidence.zip` for metric values.

## Contents

```
00_REPORT/FINAL_STS_METRICS_REPORT.md        main report (A–F + corrections) 
01_TRANSCRIPTS/
  source_ground_truth_review.csv              verified transcripts (3-ASR consensus)
  ambiguity_report.json                       flagged tokens
  transcript_verification.md                  protocol + per-source results
  transcripts_all.json                        ASR pass 1 (large-v3-turbo, word-level)
  asr_crosscheck_medium.json                  ASR pass 2 (medium)
  asr_pass3_small.json                        ASR pass 3 (small)
  source_audio/                               3 source WAVs
  HUMAN_REVIEW_REQUIRED.md                    what must be listened to
  HUMAN_REVIEW/*.wav                          6 short clips (~16 s total)
02_SIMILARITY/
  target_reference_set_FINAL.csv              10 unique targets + known-use tags + SHA-256
  common_speaker_similarity_FINAL.csv         CAMPPlus similarities + deltas
  similarity_summary_FINAL.md                 LOO stats + source baseline
  embeddings_FINAL.json                       embeddings + centroid (reproducibility)
03_PROVENANCE/
  seedvc_output_provenance.md                 SHA-256 audit of every Seed-VC output
04_CONTENT/
  content_metrics_FINAL.csv                   WER/CER per output + deltas
  content_analysis_FINAL.md                   content analysis + caveats
05_HUMAN_REVIEW/
  HUMAN_REVIEW_TASKS.md                       listening tasks (File/Timestamp/Question)
06_REPRODUCIBILITY/
  README.md                                   environment + one-command pipeline
  environment_versions.txt                    venv + GPU + frozen model versions
  scripts/                                    transcript_review.py, export_review_clips.py,
                                             campplus_sim_final.py, wer_cer_final.py,
                                             provenance_check.py
```

## Key facts

- Target centroid: 10 unique lecturer recordings (SHA-256-deduplicated over 206
  candidates). All 8 identity-study clips were byte-identical to GermanLecturerRVC
  training slices; one representation of each is kept.
- 2 Seed-VC "outputs" are byte-identical copies of their sources — excluded;
  `seedvc_metrics.txt` (0.9497/0.9463) measured the source, not Seed-VC.
- RVC_Audit8 (prepared): WER 0.061 = source's own ASR WER (Δ0.000); target
  similarity 0.912–0.957 (Δ+0.058…+0.102).
- Seed-VC (prepared): WER 0.818; (hist): no target movement (sim_to_source ≈ 0.99).
- GermanLecturerRVC (test01): worst delta (−0.158 similarity, +0.167 WER).

## Status

Human listening still required for 6 reference tokens (3-way year split,
die/das, übertragen, blah/bla ×2, die/diese, reihen/rein, gerät/gerankt semantic).
After listening, update `01_TRANSCRIPTS/source_ground_truth_review.csv` and re-run
`06_REPRODUCIBILITY/scripts/wer_cer_final.py` to refresh the WER tables.