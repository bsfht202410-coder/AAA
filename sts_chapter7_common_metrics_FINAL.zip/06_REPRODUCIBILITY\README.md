# README.md — Reproducibility

## Environments

| venv | Python | key packages |
|---|---|---|
| `C:\AI\Beatrice\tools\audiosr\.venv` | 3.11.9 | faster-whisper 1.2.1, ctranslate2 4.8.1, torch 2.6.0+cu124, librosa 0.9.2, numpy 1.26.4, soundfile 0.14.0 |
| `C:\AI\Beatrice\tools\seed-vc\.venv` | 3.11.9 | torch 2.6.0+cu124, librosa 0.10.2, soundfile 0.12.1, scipy 1.13.1 |

GPU: NVIDIA RTX A5000 Laptop. Full versions: `environment_versions.txt`.

## Pipeline (one command per stage)

1. **Transcribe (3 passes)** — not re-run here; transcript JSONs of all three
   passes are committed under `01_TRANSCRIPTS/` (turbo in `02_CONTENT/transcripts_all.json`).
   Command pattern (audiosr venv):
   `faster_whisper.WhisperModel("large-v3-turbo" | "medium" | "small", device="cuda",
   compute_type="float16")` with `language="de"`, `beam_size=5`, `temperature=0.0`,
   `vad_filter=False`, `condition_on_previous_text=True`, `word_timestamps=True`.
2. **Verify transcripts** (audiosr venv):
   `python scripts/transcript_review.py` → `01_TRANSCRIPTS/source_ground_truth_review.csv`
3. **Export review clips** (audiosr venv):
   `python scripts/export_review_clips.py` → `01_TRANSCRIPTS/HUMAN_REVIEW/*.wav`
4. **CAMPPlus similarity** (seed-vc venv, CWD `tools/seed-vc/repo`):
   `python scripts/campplus_sim_final.py` → `02_SIMILARITY/*`
5. **WER/CER** (audiosr venv):
   `python scripts/wer_cer_final.py` → `04_CONTENT/content_metrics_FINAL.csv`
6. **Provenance** (any venv):
   `python scripts/provenance_check.py` → `03_PROVENANCE/seedvc_output_provenance.md`
7. **After author listening:** update the `normalized_transcript` column of
   `source_ground_truth_review.csv`, re-run step 5 (and 4 if needed) — results refresh
   in under a minute.

## Fixed metrics protocol

- ASR: identical fixed parameters for all files (above); no VAD.
- WER/CER: pure-Python Levenshtein on normalized tokens (umlauts → ae/oe/ue,
  case/punctuation stripped); decompositions S/D/I via DP traceback.
- CAMPPlus: funasr `campplus_cn_common.bin` (192-d), mel-80 @ 16 kHz (n_fft 512,
  hop 160, fmin 0, fmax 8000), log-mel, L2-normalized embeddings, centroid =
  normalized mean of the 10 unique target recordings; LOO baseline n/mean/std/min/max;
  NO human-recognition threshold is derived.
- Targets: `target_reference_set_FINAL.csv` — every target is byte-verified unique
  (SHA-256 dedup over 206 candidate files) and tagged with known uses.

## What is NOT reproducible by script alone

- The author's listening decisions (6 clips, `05_HUMAN_REVIEW/HUMAN_REVIEW_TASKS.md`).
- RVC / Seed-VC inference itself (deliberately not re-run; no retraining, no
  regeneration — only re-measurement of existing artifacts).
- The original generation settings live in `C:\AI\Beatrice\output\seedvc_validation\
  matched_test\CONFIG_MANIFEST.txt` and the RVC settings in `sts_chapter7_evidence.zip`
  (this zip's own `00_REPORT` references it).