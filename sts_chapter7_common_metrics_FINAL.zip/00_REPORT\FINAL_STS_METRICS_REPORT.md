# FINAL_STS_METRICS_REPORT.md — Chapter 7 Common Metrics (Corrected & Finalized)

Date: 2026-08-20. Package: `sts_chapter7_common_metrics_FINAL.zip`.
This report supersedes `sts_chapter7_common_metrics.zip` and answers the six
Chapter-7 questions A–F. Tags: [MEASURED] directly computed from audio artifacts;
[DERIVED] aggregates; [HUMAN-VERIFIED] author-confirmed (pending, 6 clips);
[QUALITATIVE] contextual observations; [UNRESOLVED] not determinable from evidence.

---

## Setup (unchanged, re-measured)

- **RVC (large):** `RVC_Audit8` — 513 slices / 31.59 min / trained 545.9 min.
- **RVC (small):** `GermanLecturerRVC` — 459 slices / 22.40 min / trained 118.9 min.
- **Seed-VC:** two `1.0_30_0.7` outputs were proven to be byte-identical copies of
  their sources [MEASURED, SHA-256] and are **excluded** from all metric tables
  (see `03_PROVENANCE/seedvc_output_provenance.md`). Only 3 genuine Seed-VC outputs
  are evaluated.
- **Transcripts:** consensus of 3 independent ASR passes (turbo/medium/small);
  6 disputed tokens pending the author's listening
  (`01_TRANSCRIPTS/HUMAN_REVIEW_REQUIRED.md`) [MEASURED→HUMAN-VERIFIED pending].
- **Target centroid:** 10 unique recordings, byte-verified deduplicated by SHA-256
  over 206 candidates (`02_SIMILARITY/target_reference_set_FINAL.csv`).

---

## A. Content preservation (WER/CER vs verified reference) [MEASURED]

| source | system | WER | CER | S/D/I | delta_WER vs source |
|---|---|---|---|---|---|
| hist | RVC GermanLecturerRVC | 0.097 | 0.021 | 3/0/0 | +0.097 |
| hist | Seed-VC 100-step | 0.097 | 0.021 | 3/0/0 | +0.097 |
| hist | Seed-VC 64-step t=1.5 | **0.065** | 0.011 | 2/0/0 | +0.065 |
| test01 | RVC GermanLecturerRVC | 0.167 | 0.052 | 2/0/2 | +0.167 |
| prepared | RVC_Audit8 (4 configs) | **0.061** | 0.023–0.033 | 2/0/0 | **+0.000** |
| prepared | Seed-VC baseline | **0.818** | 0.558 | 19/4/4 | +0.758 |

ASR source baselines: hist 0.000, test01 0.000, prepared 0.061 (2 tokens the turbo
pass transcribes differently from the verified consensus: "die"→"diese",
"reihen"→"rein"; an ASR-measurement nuance, not an audio defect) [MEASURED].

**Finding A1:** On the prepared sentence, all four RVC_Audit8 configs reach WER 0.061 —
identical to the source's own ASR baseline. RVC_Audit8 is **content-preserving at the
ASR-measurable level** on this sentence. [MEASURED]

**Finding A2:** The Seed-VC baseline destroys the prepared content (WER 0.818).
The previous package's favorable Seed-VC content reading is not supported. [MEASURED]

## B. Target similarity (CAMPPlus vs 10-clip lecturer centroid) [MEASURED]

Genuine-target LOO distribution: n=10, mean=0.9469, std=0.0196, min=0.9202,
max=0.9743 [DERIVED]. Sources vs centroid: hist 0.8802, test01 0.9187,
prepared 0.8544.

| source | system | sim to centroid | sim to source | delta vs source |
|---|---|---|---|---|
| hist | RVC GermanLecturerRVC | 0.8631 | 0.7142 | −0.0171 |
| hist | Seed-VC 100-step | 0.8964 | 0.9914 | +0.0162 |
| hist | Seed-VC 64-step t=1.5 | 0.8776 | 0.9886 | −0.0026 |
| test01 | RVC GermanLecturerRVC | 0.7605 | 0.6706 | −0.1583 |
| prepared | RVC_Audit8 h0 | 0.9246 | 0.9203 | +0.0702 |
| prepared | RVC_Audit8 h2 | **0.9565** | 0.8839 | **+0.1022** |
| prepared | RVC_Audit8 r0 | 0.9122 | 0.9295 | +0.0578 |
| prepared | RVC_Audit8 r2 | **0.9540** | 0.8805 | +0.0996 |
| prepared | Seed-VC baseline | 0.9178 | 0.7943 | +0.0634 |

**Finding B1:** RVC_Audit8's prepared outputs (0.912–0.957) sit at or above the
source's own similarity (0.854) and inside/above the genuine-target LOO band
(min 0.9202) — i.e. the converted voice is as close to the lecturer centroid as
genuine lecturer recordings are to each other [MEASURED]. No human-perception
threshold is claimed (see F).

**Finding B2:** GermanLecturerRVC on test01 moves AWAY from the target (−0.158),
the largest negative delta in the study.

## C. Delta movement (toward / away from target) [DERIVED]

- Largest positive target-movement: **RVC_Audit8 on prepared (+0.058…+0.102)**
  — the conversion moves the author's voice toward the lecturer centroid.
- Largest negative: **GermanLecturerRVC on test01 (−0.158)**.
- Seed-VC on hist shows **negligible movement** (+0.016 / −0.003) with
  similarity_to_source ≈ 0.99 — the voice was barely transformed on this sentence.
- On content, deltas mirror this: RVC_Audit8 prepared ΔWER 0.000; Seed-VC prepared
  ΔWER +0.758.

## D. Smaller vs larger RVC model

Not directly rankable: the two RVC models were evaluated on **different sentences**
(RVC_Audit8 on the 33-word prepared text; GermanLecturerRVC on the 31/24-word hist
and test01 texts). Cross-sentence WER/CAMPPlus comparisons are confounded.
Within-sentence statements: RVC_Audit8 (larger, 513 slices / 31.6 min) achieves
ΔWER 0.000 and positive target deltas on prepared; GermanLecturerRVC (smaller,
459 slices / 22.4 min) achieves ΔWER +0.097/+0.167 and negative target deltas on
hist/test01. Any "larger RVC is better" claim would require identical source
sentences — [UNRESOLVED] without a new experiment (out of scope: no regeneration).

## E. Seed-VC claim

The prior claim that Seed-VC rivals or beats RVC on the lecturer similarity is
**not supported** [MEASURED]:

1. The two headline Seed-VC values (0.9497 / 0.9463 in `seedvc_metrics.txt`) were
   computed on byte-identical copies of the source — they measure source-vs-lecturer,
   not Seed-VC output. Excluded.
2. Genuine Seed-VC on hist: similarity 0.878–0.896 ≈ source's own 0.8802, with
   similarity_to_source ≈ 0.99 → **negligible voice transformation toward the target**.
3. Genuine Seed-VC on prepared: content destroyed (WER 0.818); similarity 0.9178 is
   comparable to RVC_Audit8's 0.912–0.957 but with 0.758 worse WER.

Conclusion: no evidence that Seed-VC provides better resemblance or better content
preservation than RVC in this setup; the best Seed-VC artifact is the 64-step/t=1.5
hist output (best overall WER 0.065, but no target movement).

## F. Human-perception disclaimer

CAMPPlus cosine is an objective, model-based embedding similarity. It is **not** a
perceptual measure; no threshold or claim ("sounds like the same person") is derived
from it. The LOO distribution is reported only as reference dispersion. Perceived
identity can only be established by listening — the author's review tasks are in
`05_HUMAN_REVIEW/HUMAN_REVIEW_TASKS.md` (6 clips, ~16 s). Until completed, all
perceptual statements are [HUMAN-VERIFIED: pending] and the numerical findings are
[MEASURED] but not [HUMAN-VERIFIED].

---

## Corrections to previous STS evidence

1. **Target centroid contained duplicate content.** All 5 `prof_ref_*` and all 3
   `prof_holdout_*` identity-study clips are byte-identical to GermanLecturerRVC
   training slices (SHA-256), and the previous package's `train_slice_audio1` was
   the same recording as `prof_ref_01`. FINAL centroid: 10 unique recordings
   (one representation per duplicated slice + two unique slices) [MEASURED].
2. **`seedvc_metrics.txt` measured the source, not Seed-VC.** Both `1.0_30_0.7`
   "outputs" are byte-identical copies of their inputs; excluded. The FINAL
   Seed-VC numbers come only from genuine outputs [MEASURED].
3. **RVC_Audit8 WER changed 0.091 → 0.061** (prepared) purely from the verified
   reference (2-token change); the audio and ASR hypotheses are unchanged [MEASURED].
4. **Seed-VC prepared WER changed 0.788 → 0.818** for the same reason [MEASURED].
5. **CAMPPlus LOO changed 0.9455 → 0.9469** and per-file similarities shifted due to
   the corrected centroid (dedup + new unique slice) [DERIVED].
6. **Identity-study integrity note (outside STS scope):** the identity study's
   "prof holdout" baseline clips are GermanLecturerRVC training slices; if the
   beatrice CUSTOM model was trained on the same 196-clip set, its "genuine target"
   baseline was trained-on data. The thesis should re-examine the identity study's
   holdout interpretation [QUALITATIVE].

## Three strongest findings

1. [MEASURED] RVC_Audit8 preserves content on the prepared sentence at the source's
   own ASR WER (0.061, ΔWER 0.000) and moves the voice toward the lecturer centroid
   (Δ+0.058…+0.102, up to 0.9565).
2. [MEASURED] The two headline Seed-VC results were byte-identical source copies —
   invalid as evidence; genuine Seed-VC shows no target movement on hist and
   destroys the prepared content (WER 0.818).
3. [MEASURED] GermanLecturerRVC's test01 output drops 0.158 in target similarity
   and gains 0.167 in WER vs its source — the worst conversion of the set.

## Human review still required

Yes — 6 clips in `01_TRANSCRIPTS/HUMAN_REVIEW/` (~16 s total), listed in
`05_HUMAN_REVIEW/HUMAN_REVIEW_TASKS.md`, resolve the 6 disputed reference tokens
(including the 3-way year split [UNRESOLVED] and the "gerät/gerankt" semantic
question [QUALITATIVE]). Until completed, `source_ground_truth_review.csv` rows are
ASR consensus, and this report's tables are [MEASURED] but not [HUMAN-VERIFIED].