"""export_review_clips.py - slice the ambiguous segments of the 3 source recordings
into short WAV clips for human listening review (01_TRANSCRIPTS/HUMAN_REVIEW/).

Segments cover every token where the three ASR passes disagreed (anchored to turbo
word timestamps, padded by 0.4 s) plus the 'gerät/gerankt' region (all three models
agree on 'gerät' but the PageRank context suggests 'gerankt' - semantic check only).
"""
import os
import soundfile as sf

STAGE = r"C:\AI\Beatrice\output\sts_final_metrics_stage\sts_chapter7_common_metrics_FINAL"
OUT = os.path.join(STAGE, "01_TRANSCRIPTS", "HUMAN_REVIEW")

SOURCES = {
    "hist": r"C:\AI\Beatrice\output\seedvc_validation\seedvc_hist_lecturer.wav",
    "test01": r"C:\AI\Beatrice\output\seedvc_validation\seedvc_test01_lecturer.wav",
    "prepared": r"C:\AI\Beatrice\output\seedvc_validation\matched_test\source_mine_prepared_48k.wav",
}

# (source_id, label, start_s, end_s, reason)
CLIPS = [
    ("hist", "A_die-das-spezifische", 4.0, 6.0,
     "turbo+medium 'die spezifische Technik' vs small 'das spezifische Technik'"),
    ("hist", "B_jahr_1972-1970-1901", 9.4, 11.4,
     "year token: turbo '1972', medium '1970', small '1901' (3-way disagreement)"),
    ("hist", "C_uebertragen", 12.8, 15.0,
     "turbo+medium 'uebertragen' vs small 'uebertagen'"),
    ("hist", "D_blah-blah", 16.2, 19.4,
     "turbo+small 'Blah und Blah' vs medium 'Bla und Bla'"),
    ("prepared", "A_diese-seiten-geraet-hat", 4.4, 7.0,
     "turbo 'die Seiten' vs medium+small 'diese Seiten'; all three hear 'gerät hat' "
     "(context PageRank suggests 'gerankt' - semantic check)"),
    ("prepared", "B_zu-reihen-rein", 13.0, 17.4,
     "turbo 'zu reihen' vs medium+small 'zu rein'"),
]


def main():
    os.makedirs(OUT, exist_ok=True)
    for src_id, label, st, en, reason in CLIPS:
        wav = SOURCES[src_id]
        data, sr = sf.read(wav, dtype="float32")
        i0, i1 = int(st * sr), int(en * sr)
        seg = data[i0:i1]
        name = f"{src_id}__{label}__{st:.1f}-{en:.1f}s.wav"
        sf.write(os.path.join(OUT, name), seg, sr)
        print(f"{name}: {len(seg) / sr:.1f}s  ({reason})")


if __name__ == "__main__":
    main()