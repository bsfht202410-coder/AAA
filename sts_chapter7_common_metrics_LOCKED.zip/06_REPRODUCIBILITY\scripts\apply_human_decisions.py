"""apply_human_decisions.py - overwrite the ASR-consensus transcripts with the
HUMAN-VERIFIED listening decisions and mark them accordingly.

Decisions (author listening, 2026-08-20):
  hist    year            = 1972
  hist    article         = "das spezifische Technik"   (preserve as spoken, do NOT
                          correct to "die")
  hist    verb            = uebertragen
  hist    final phrase    = "Bla und Bla"
  prepared phrase         = "die Seiten gereiht hat"
  prepared verb           = reihen
  test01                  = verbatim agreement of all three ASR passes (no decision
                          needed)

This is the only place the ground truth is edited by hand. Re-run
wer_cer_final.py afterwards to refresh all WER/CER tables.
"""
import csv
import os

STAGE = r"C:\AI\Beatrice\output\sts_final_metrics_stage\sts_chapter7_common_metrics_FINAL"
CSV = os.path.join(STAGE, "01_TRANSCRIPTS", "source_ground_truth_review.csv")

HUMAN = {
    "hist": (
        "Wir werden das jetzt speichern und für Speichern verwenden wir das spezifische Technik von Euler. "
        "Euler wurde 1972 dieses Wissen übertragen und er hat uns Sachen wie Bla und Bla gegeben.",
        "wir werden das jetzt speichern und fuer speichern verwenden wir das spezifische technik von euler "
        "euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie bla und bla gegeben",
        "Human decisions (listening): year=1972; article='das spezifische Technik' (preserved as spoken, "
        "not corrected to 'die'); verb='uebertragen'; final phrase='Bla und Bla' (turbo/small 'Blah' rejected).",
    ),
    "prepared": (
        "Auf welchen Gesichtspunkten ursprünglich Google seine Seiten oder die Seiten gereiht hat. "
        "Also der Google Page Rank Algorithmus, der dient dem dazu, um Seiten zu reihen und ein bisschen "
        "fast schon übertrieben kitschig.",
        "auf welchen gesichtspunkten urspruenglich google seine seiten oder die seiten gereiht hat also "
        "der google page rank algorithmus der dient dem dazu um seiten zu reihen und ein bisschen fast "
        "schon uebertrieben kitschig",
        "Human decisions (listening): phrase='die Seiten gereiht hat' (not 'diese Seiten gerät hat'); "
        "verb='reihen' (not 'rein'). All three ASR passes misheard 'gerät'; human confirms 'gereiht'.",
    ),
}

with open(CSV, encoding="utf-8", newline="") as f:
    rows = list(csv.DictReader(f))

for r in rows:
    if r["source_id"] in HUMAN:
        verbatim, normed, note = HUMAN[r["source_id"]]
        r["proposed_verbatim_transcript"] = verbatim
        r["normalized_transcript"] = normed
        r["confidence"] = "HUMAN-VERIFIED"
        r["human_review_required"] = "NO"
        r["notes"] = note
    else:
        r["confidence"] = "HUMAN-VERIFIED (3/3 ASR agreement, no listening needed)"
        r["human_review_required"] = "NO"
        r["notes"] = "All three ASR passes agree verbatim; no ambiguity existed."

fieldnames = list(rows[0].keys())
with open(CSV, "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=fieldnames)
    w.writeheader()
    w.writerows(rows)
for r in rows:
    print(r["source_id"], "->", r["confidence"], "| review:", r["human_review_required"])
    print("   norm:", r["normalized_transcript"])
print("wrote", CSV)