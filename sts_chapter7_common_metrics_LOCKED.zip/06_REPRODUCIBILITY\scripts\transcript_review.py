"""transcript_review.py - multi-ASR transcript verification for the 3 source recordings.

Three independent German-capable ASR passes on the SAME sources:
  A: faster-whisper large-v3-turbo  (fixed protocol of the previous package)
  B: faster-whisper medium
  C: faster-whisper small
All with language='de', beam_size=5, temperature=0.0, vad_filter=False.

Alignment: medium and small token sequences are aligned onto the turbo sequence
(Levenshtein); per turbo position the three models' tokens are compared. Positions
where the models disagree are flagged for human review with timestamps anchored to
the turbo word-level segmentation.

Rule: never silently guess an unclear word. A token is proposed only by majority of
the three models; on a 3-way disagreement the turbo token is kept for the WER
reference but marked UNRESOLVED for the human.

Writes:
  01_TRANSCRIPTS/source_ground_truth_review.csv
  01_TRANSCRIPTS/ambiguity_report.json
"""
import csv
import json
import os
import re
import unicodedata

STAGE = r"C:\AI\Beatrice\output\sts_final_metrics_stage\sts_chapter7_common_metrics_FINAL"
OLD = r"C:\AI\Beatrice\output\sts_common_metrics_stage\sts_chapter7_common_metrics"

TURBO = json.load(open(os.path.join(OLD, "02_CONTENT", "transcripts_all.json"), encoding="utf-8"))["files"]
MEDIUM = json.load(open(os.path.join(OLD, "01_TRANSCRIPTS", "asr_crosscheck_medium.json"), encoding="utf-8"))["files"]
SMALL = json.load(open(os.path.join(OLD, "01_TRANSCRIPTS", "asr_pass3_small.json"), encoding="utf-8"))

SOURCES = [
    ("hist", "seedvc_hist_lecturer.wav"),
    ("test01", "seedvc_test01_lecturer.wav"),
    ("prepared", "source_mine_prepared_48k.wav"),
]

FILLERS = {"aeh", "aehm", "ah", "mh", "uh", "hm", "mmh"}
PUNCT = re.compile(r"[^a-z0-9 ]")


def norm(text):
    t = unicodedata.normalize("NFKC", text)
    t = t.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    t = t.lower()
    t = PUNCT.sub("", t)
    return [w for w in t.split() if w and w not in FILLERS]


def lev_trace(a, b):
    """Levenshtein alignment -> list of (op, i, j); i indexes a (ref=turbo), j indexes b."""
    prev = list(range(len(b) + 1))
    prev_trace = [[("i", -1, k) for k in range(j)] for j in range(len(b) + 1)]
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        cur_trace = [prev_trace[0] + [("d", i - 1, -1)]] + [None] * len(b)
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            diag = prev[j - 1] + cost
            up = prev[j] + 1
            left = cur[j - 1] + 1
            if diag <= up and diag <= left:
                cur[j], cur_trace[j] = diag, prev_trace[j - 1] + [("m" if cost == 0 else "s", i - 1, j - 1)]
            elif up <= left:
                cur[j], cur_trace[j] = up, prev_trace[j] + [("d", i - 1, -1)]
            else:
                cur[j], cur_trace[j] = left, cur_trace[j - 1] + [("i", -1, j - 1)]
        prev, prev_trace = cur, cur_trace
    return prev_trace[-1]


def aligned_tokens(turbo_tok, other_tok):
    """Per-turbo-position list of other-model tokens (None = model missed the word)."""
    out = [None] * len(turbo_tok)
    for op, i, j in lev_trace(turbo_tok, other_tok):
        if op in ("m", "s"):
            out[i] = other_tok[j]
        elif op == "d":
            out[i] = None
        # 'i' = other-model insertion, handled separately below
    ins = [other_tok[j] for op, i, j in lev_trace(turbo_tok, other_tok) if op == "i"]
    return out, ins


def build_rows():
    rows = []
    for fid, fn in SOURCES:
        t_tok = norm(TURBO[fn]["text"])
        m_tok = norm(MEDIUM[fn]["text"])
        s_tok = norm(SMALL[fid]["text"])
        t_words = [(w["word"].strip(), w["start"], w["end"]) for w in TURBO[fn].get("words", [])]

        m_align, m_ins = aligned_tokens(t_tok, m_tok)
        s_align, s_ins = aligned_tokens(t_tok, s_tok)

        proposed, flags = [], []
        for i, w in enumerate(t_tok):
            opts = [w, m_align[i], s_align[i]]
            opts = [o for o in opts if o is not None]
            uniq = sorted(set(opts))
            if len(uniq) == 1:
                proposed.append(w)
            else:
                votes = {u: opts.count(u) for u in uniq}
                best = max(votes, key=votes.get)
                if votes[best] == 1 and len(uniq) == 3:
                    best = w  # 3-way split: keep turbo for WER reference, flag UNRESOLVED
                proposed.append(best)
                flags.append({"position": i, "turbo": w, "medium": m_align[i], "small": s_align[i],
                              "proposed": best, "unresolved": votes[best] == 1 and len(uniq) == 3})
        for w in set(m_ins + s_ins):
            flags.append({"position": None, "turbo": None, "medium": w if w in m_ins else None,
                          "small": w if w in s_ins else None, "proposed": None,
                          "unresolved": False, "extra_token_from_models": True})

        # suppress tokenization-only disagreements: other-model token that is the
        # exact concatenation of two adjacent turbo tokens (e.g. 'pagerank' vs 'page rank')
        flags = [fl for fl in flags
                 if not (fl.get("position") is not None and
                         (m_align[fl["position"]] is not None and
                          m_align[fl["position"]] == t_tok[fl["position"]] + (t_tok[fl["position"] + 1] if fl["position"] + 1 < len(t_tok) else ""))
                         and (s_align[fl["position"]] is None or s_align[fl["position"]] == t_tok[fl["position"]]))]

        # group contiguous insertion-only flags (e.g. a whole repeated sentence) into
        # one artifact entry
        if flags:
            merged = [fl for fl in flags if fl.get("position") is not None]
            ins_flags = [fl for fl in flags if fl.get("position") is None]
            if ins_flags:
                merged.append({"position": None, "turbo": None,
                               "medium": "/".join(sorted({f["medium"] for f in ins_flags if f["medium"]}) or ["-"]),
                               "small": "/".join(sorted({f["small"] for f in ins_flags if f["small"]}) or ["-"]),
                               "proposed": None, "unresolved": False,
                               "extra_token_from_models": True,
                               "artifact": "contiguous insertions from one or more models"})
            flags = merged

        # timestamps for flagged turbo positions (index-aligned to turbo word segments)
        for fl in flags:
            if fl.get("position") is None:
                fl["start"], fl["end"] = None, None
                continue
            i = fl["position"]
            st, en = None, None
            if i < len(t_words):
                tw, ws, we = t_words[i]
                st, en = ws, we
            fl["start"], fl["end"] = st, en

        need_review = bool(flags)
        ts_txt = "; ".join(f"{f.get('proposed','?')} @ {f.get('start')}-{f.get('end')}s "
                           f"[turbo={f.get('turbo')} medium={f.get('medium')} small={f.get('small')}]"
                           for f in flags)

        rows.append({
            "source_id": fid,
            "source_wav": fn,
            "asr_1_transcript": TURBO[fn]["text"],
            "asr_2_transcript": MEDIUM[fn]["text"],
            "asr_3_transcript": SMALL[fid]["text"],
            "project_text_if_available": "none found (recursive search of project .md/.txt/.csv/.py/.json/.log for distinctive words: Fahrradfahrer, Gesichtspunkten, PageRank, Euler, Blah, Kitsch, speichern)",
            "proposed_verbatim_transcript": " ".join(proposed),
            "normalized_transcript": " ".join(proposed),
            "confidence": "MEDIUM" if need_review else "HIGH",
            "human_review_required": "YES" if need_review else "NO",
            "uncertain_segment_timestamp": ts_txt or "none",
            "notes": ("Consensus of 3 ASR passes (turbo/medium/small) via Levenshtein "
                      "alignment; flagged tokens need listening. Timestamps anchored to "
                      "turbo word segmentation. UNRESOLVED = 3-way split, turbo kept for "
                      "WER reference."),
        })
    return rows


def main():
    rows = build_rows()
    with open(os.path.join(STAGE, "01_TRANSCRIPTS", "source_ground_truth_review.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    for r in rows:
        print(r["source_id"], "| conf:", r["confidence"], "| review:", r["human_review_required"])
        print("   ", r["uncertain_segment_timestamp"][:400])
    with open(os.path.join(STAGE, "01_TRANSCRIPTS", "ambiguity_report.json"), "w",
              encoding="utf-8") as f:
        json.dump([{"source_id": r["source_id"], "uncertain_segment_timestamp": r["uncertain_segment_timestamp"]}
                   for r in rows if r["human_review_required"] == "YES"], f, indent=1, ensure_ascii=False)
    print("wrote source_ground_truth_review.csv + ambiguity_report.json")


if __name__ == "__main__":
    main()