# MANIFEST — sts_chapter7_common_metrics_LOCKED.zip

Locked common-metrics package for Chapter 7 (RVC vs Seed-VC voice conversion toward
the German lecturer). Transcripts are [HUMAN-VERIFIED] (all 6 ambiguous segments
resolved by author listening, 2026-08-20). Supersedes
`sts_chapter7_common_metrics_FINAL.zip`, `sts_chapter7_common_metrics.zip`, and
`sts_chapter7_evidence.zip` for metric values. CAMPPlus results unchanged from the
FINAL package (no re-run).

## Contents

```
00_REPORT/FINAL_STS_METRICS_REPORT.md        main report (A–F + corrections + qualifications)
01_TRANSCRIPTS/
  source_ground_truth_review.csv              HUMAN-VERIFIED transcripts + decisions
  ambiguity_report.json                       formerly flagged tokens (now resolved)
  transcript_verification.md                  protocol + per-source results + completion log
  transcripts_all.json                        ASR pass 1 (large-v3-turbo, word-level)
  asr_crosscheck_medium.json                  ASR pass 2 (medium)
  asr_pass3_small.json                        ASR pass 3 (small)
  source_audio/                               3 source WAVs
  HUMAN_REVIEW_REQUIRED.md                    record of the completed listening review
  HUMAN_REVIEW/*.wav                          6 short clips (~16 s total, resolved)
02_SIMILARITY/
  target_reference_set_FINAL.csv              10 unique targets + known-use tags + SHA-256
  common_speaker_similarity_FINAL.csv         CAMPPlus similarities + deltas (unchanged)
  similarity_summary_FINAL.md                 LOO stats + methodological qualification
  embeddings_FINAL.json                       embeddings + centroid (reproducibility)
03_PROVENANCE/
  seedvc_output_provenance.md                 SHA-256 audit of every Seed-VC output
04_CONTENT/
  content_metrics_FINAL.csv                   WER/CER per output + deltas (HUMAN-VERIFIED refs)
  content_analysis_FINAL.md                   content analysis + corrections
05_HUMAN_REVIEW/
  HUMAN_REVIEW_TASKS.md                       completed listening tasks + resolutions
06_REPRODUCIBILITY/
  README.md                                   environment + one-command pipeline
  environment_versions.txt                    venv + GPU + frozen model versions
  scripts/                                    transcript_review.py, export_review_clips.py,
                                             campplus_sim_final.py, wer_cer_final.py,
                                             provenance_check.py, apply_human_decisions.py
```

## Key facts (LOCKED)

- Reference transcripts: HUMAN-VERIFIED. hist = "…das spezifische Technik… 1972 …
  übertragen … Sachen wie Bla und Bla"; prepared = "…die Seiten gereiht hat … zu
  reihen …"; test01 = 3/3 ASR agreement.
- Content (WER): Seed-VC 100-step hist **0.000**; Seed-VC 64-step hist 0.032;
  RVC hist 0.065; RVC_Audit8 prepared 0.061 (Δ+0.030 vs source); RVC test01 0.167;
  Seed-VC prepared 0.758.
- Similarity (CAMPPlus, unchanged): LOO n=10 mean 0.9469 (min 0.9202, max 0.9743);
  RVC_Audit8 prepared 0.912–0.957 (Δ+0.058…+0.102); GermanLecturerRVC test01 0.7605
  (Δ−0.158); Seed-VC hist variants 0.878–0.896 (sim_to_source ≈ 0.99).
- 2 Seed-VC "outputs" are byte-identical source copies — excluded.
- Methodological qualification: centroid is authentic target speech but not a
  held-out corpus w.r.t. RVC training material; similarities are descriptive
  embedding measurements, not generalization estimates.

## Status

No further transcript review required. Remaining open items (do not block use):
identity-listening experiment (perception), cross-sentence system comparison,
test01 "Well" artifact wording, identity-study holdout caveat — all documented in
the report's "Remaining evidence problems".