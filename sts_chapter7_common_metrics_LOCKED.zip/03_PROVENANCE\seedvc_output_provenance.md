# seedvc_output_provenance.md

SHA-256 audit of every claimed Seed-VC output vs its claimed source. A claimed output is a **valid conversion** only if it differs from the source at the byte level; byte-identical files are excluded from all metric tables.

| file | sha256 | source_file | byte_identical_to_source | valid_conversion |
|---|---|---|---|---|
| vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav | 4741f903e0d36435de10a7557ded4f8f5b0fb5ef48ce2f43a04f0a361c4c127e | seedvc_hist_lecturer.wav | YES | NO - byte-identical copy |
| vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav | 955bb7c0e7061f5e867d6f0913f30ff5ca3a8beb669745bce7893818a74ddd5f | seedvc_test01_lecturer.wav | YES | NO - byte-identical copy |
| vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav | 3214123c796229bf09e65c44e089bcbf1c3ceb514d2b188367287fb1838f4c16 | seedvc_hist_lecturer.wav | NO | YES |
| vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav | 79a873515172341efe5f1423feee319b26bfb2f8afd5b772dbafb2bb93e36b2b | seedvc_hist_lecturer.wav | NO | YES |
| result_baseline_newrec.wav | aa3d17c027dfbfc36d6ac842c84c978a6aa77a549659a9b891527d2a3b7fdc61 | source_mine_prepared_48k.wav | NO | YES |

## Genuine Seed-VC outputs (used in metrics)

| file | sha256 | identical_to_source |
|---|---|---|
| vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav | 3214123c796229bf09e65c44e089bcbf1c3ceb514d2b188367287fb1838f4c16 | False |
| vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav | 79a873515172341efe5f1423feee319b26bfb2f8afd5b772dbafb2bb93e36b2b | False |
| result_baseline_newrec.wav | aa3d17c027dfbfc36d6ac842c84c978a6aa77a549659a9b891527d2a3b7fdc61 | False |

## Excluded / reference files

| file | sha256 |
|---|---|
| seedvc_hist_lecturer.wav | 4741f903e0d36435de10a7557ded4f8f5b0fb5ef48ce2f43a04f0a361c4c127e |
| seedvc_test01_lecturer.wav | 955bb7c0e7061f5e867d6f0913f30ff5ca3a8beb669745bce7893818a74ddd5f |
| source_mine_prepared_48k.wav | c24e1e7c67f1130d76d586a7bfebad53ffab13b2516bb52c5f159663215f642a |
| seedvc_ref_lecturer.wav | 613ffef8012e44cd19c813ed2c7af940996fb5199eb00c284357e57b939d86ff |
| target_gt_lecturer_mono.wav | ca960903af32a8e3b204f6495219dd088063dd0a10448bc9242e432251963f86 |

## Conclusion

- `vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav` == `seedvc_hist_lecturer.wav` (byte-identical): the pipeline wrote a copy of the source, not a conversion. The previous package's `seedvc_metrics.txt` values (0.9497 / 0.9463) measured source-vs-lecturer, NOT Seed-VC output, and are excluded from the FINAL report.
- `vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav` == `seedvc_test01_lecturer.wav` (byte-identical): same conclusion.
- The three retained outputs (100-step, 64-step/t=1.5, prepared baseline) differ from their sources at the byte level and are valid conversion artifacts.
- `seedvc_ref_lecturer.wav` (23.33 s) and `target_gt_lecturer_mono.wav` are NOT duplicates of any target-reference or training slice and are excluded from the target centroid by design (known-use rules in target_reference_set_FINAL.csv).