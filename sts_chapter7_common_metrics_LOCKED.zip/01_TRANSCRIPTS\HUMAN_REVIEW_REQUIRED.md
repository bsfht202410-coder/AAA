# HUMAN_REVIEW_REQUIRED.md — COMPLETED

**Status: all 6 segments were listened to and resolved by the author on
2026-08-20. The decisions below are applied in `source_ground_truth_review.csv`
(tag [HUMAN-VERIFIED]) and no further listening is required for the transcripts.**

The source transcripts in `source_ground_truth_review.csv` are **HUMAN-VERIFIED**:
consensus of 3 independent ASR passes (faster-whisper large-v3-turbo / medium /
small) plus direct listening of every disputed segment. This file records what was
verified.

## Resolved decisions

| # | clip | disagreement | HUMAN DECISION (applied) |
|---|---|---|---|
| 1 | `hist__B_jahr_1972-1970-1901__9.4-11.4s.wav` | turbo `1972`, medium `1970`, small `1901` | **1972** |
| 2 | `hist__A_die-das-spezifische__4.0-6.0s.wav` | turbo+medium `die`, small `das` | **"das spezifische Technik"** — preserved exactly as spoken, not corrected to "die" |
| 3 | `hist__C_uebertragen__12.8-15.0s.wav` | turbo+medium `übertragen`, small `übertagen` | **übertragen** |
| 4 | `hist__D_blah-blah__16.2-19.4s.wav` | turbo+small `Blah`, medium `Bla` (×2) | **"Bla und Bla"** |
| 5 | `prepared__A_diese-seiten-geraet-hat__4.4-7.0s.wav` | "die/diese"; all three ASR hear `gerät` (context suggested `gerankt`) | **"die Seiten gereiht hat"** — human confirms "gereiht" |
| 6 | `prepared__B_zu-reihen-rein__13.0-17.4s.wav` | turbo `reihen`, medium+small `rein` | **reihen** |

## Sensitivity note (now moot)

Every disputed token shifted WER by ≤1/33–1/31 under the previous ASR-consensus
reference; all tokens are now human-confirmed, so the LOCKED tables contain no
reference uncertainty.