"""wer_cer_final.py - WER/CER of every conversion output against the VERIFIED source
transcripts (source_ground_truth_review.csv), plus the ASR baseline per source
(WER of the turbo transcript of the source itself).

- Raw WER/CER stays primary (no subtraction/correction).
- delta_wer_vs_source / delta_cer_vs_source are provided for context only.
- Ambiguous reference tokens follow the 3-model consensus; tokens flagged for human
  review are listed in content_analysis_FINAL.md together with the WER sensitivity
  (max +/- 1 token per flagged position).
"""
import csv
import json
import os
import re
import unicodedata

STAGE = r"C:\AI\Beatrice\output\sts_final_metrics_stage\sts_chapter7_common_metrics_FINAL"
OLD = r"C:\AI\Beatrice\output\sts_common_metrics_stage\sts_chapter7_common_metrics"

REVIEW_CSV = os.path.join(STAGE, "01_TRANSCRIPTS", "source_ground_truth_review.csv")
TURBO = json.load(open(os.path.join(OLD, "02_CONTENT", "transcripts_all.json"), encoding="utf-8"))["files"]

PUNCT = re.compile(r"[^a-z0-9 ]")

SOURCES = {
    "hist": "seedvc_hist_lecturer.wav",
    "test01": "seedvc_test01_lecturer.wav",
    "prepared": "source_mine_prepared_48k.wav",
}

OUTPUTS = [
    ("rvc_hist_lecturer.wav", "RVC_Audit8", "hist"),
    ("rvc_test01_lecturer.wav", "RVC_Audit8", "test01"),
    ("rvc_harvest_p0.wav", "RVC_Audit8", "prepared"),
    ("rvc_harvest_p2.wav", "RVC_Audit8", "prepared"),
    ("rvc_rmvpe_p0.wav", "RVC_Audit8", "prepared"),
    ("rvc_rmvpe_p2.wav", "RVC_Audit8", "prepared"),
    ("result_baseline_newrec.wav", "Seed-VC", "prepared"),
    ("vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav", "Seed-VC", "hist"),
    ("vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav", "Seed-VC", "hist"),
]


def norm(text):
    t = unicodedata.normalize("NFKC", text)
    t = t.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    t = t.lower()
    t = PUNCT.sub("", t)
    return [w for w in t.split()]


def lev(a, b):
    prev = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] != b[j - 1]))
        prev = cur
    return prev[-1]


def wer_details(ref, hyp):
    n = len(ref)
    if n == 0:
        return 1.0, 0, 0, 0, 0
    d = lev(ref, hyp)
    # decompose into subs/dels/ins via aligned DP (same matrix, trace)
    m = len(ref) + 1
    mat = [[0] * (len(hyp) + 1) for _ in range(m)]
    for i in range(m):
        mat[i][0] = i
    for j in range(len(hyp) + 1):
        mat[0][j] = j
    for i in range(1, m):
        for j in range(1, len(hyp) + 1):
            mat[i][j] = min(mat[i - 1][j] + 1, mat[i][j - 1] + 1,
                            mat[i - 1][j - 1] + (ref[i - 1] != hyp[j - 1]))
    i, j = len(ref), len(hyp)
    subs = dels = ins = 0
    while i > 0 or j > 0:
        if i > 0 and j > 0 and mat[i][j] == mat[i - 1][j - 1] + (ref[i - 1] != hyp[j - 1]):
            subs += ref[i - 1] != hyp[j - 1]
            i, j = i - 1, j - 1
        elif i > 0 and mat[i][j] == mat[i - 1][j] + 1:
            dels += 1
            i -= 1
        else:
            ins += 1
            j -= 1
    return d, subs, dels, ins, n


def cer(ref_tok, hyp_tok):
    r = " ".join(ref_tok)
    h = " ".join(hyp_tok)
    d = lev(list(r), list(h))
    return d / max(1, len(r)), d, len(r)


def load_review():
    refs = {}
    with open(REVIEW_CSV, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            refs[row["source_id"]] = norm(row["normalized_transcript"])
    return refs


def main():
    refs = load_review()
    rows = []
    baseline = {}
    for sid, fn in SOURCES.items():
        d, subs, dels, ins, n = wer_details(refs[sid], norm(TURBO[fn]["text"]))
        c, cd, cr = cer(refs[sid], norm(TURBO[fn]["text"]))
        baseline[sid] = (d / n, c)
        rows.append({"file": fn, "model": "SOURCE (ASR baseline)", "source_id": sid,
                     "wer": round(d / n, 4), "cer": round(c, 4),
                     "subs": subs, "dels": dels, "ins": ins, "ref_words": n,
                     "delta_wer_vs_source": 0.0, "delta_cer_vs_source": 0.0,
                     "hypothesis": TURBO[fn]["text"]})
    for fn, model, sid in OUTPUTS:
        d, subs, dels, ins, n = wer_details(refs[sid], norm(TURBO[fn]["text"]))
        c, cd, cr = cer(refs[sid], norm(TURBO[fn]["text"]))
        bw, bc = baseline[sid]
        rows.append({"file": fn, "model": model, "source_id": sid,
                     "wer": round(d / n, 4), "cer": round(c, 4),
                     "subs": subs, "dels": dels, "ins": ins, "ref_words": n,
                     "delta_wer_vs_source": round(d / n - bw, 4),
                     "delta_cer_vs_source": round(c - bc, 4),
                     "hypothesis": TURBO[fn]["text"]})
    with open(os.path.join(STAGE, "04_CONTENT", "content_metrics_FINAL.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    for r in rows:
        print(f"{r['source_id']:9s} {r['model']:20s} WER={r['wer']:.3f} CER={r['cer']:.3f} "
              f"(S{r['subs']}/D{r['dels']}/I{r['ins']}, n={r['ref_words']}) "
              f"dWER={r['delta_wer_vs_source']:+.3f}")


if __name__ == "__main__":
    main()