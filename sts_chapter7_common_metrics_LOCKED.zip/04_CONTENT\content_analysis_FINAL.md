# content_analysis_FINAL.md

Content preservation of every conversion output, measured as WER/CER against the
**HUMAN-VERIFIED** source transcripts (`01_TRANSCRIPTS/source_ground_truth_review.csv`).
The reference transcripts were confirmed by direct listening on 2026-08-20
(6 ambiguous segments resolved; `test01` needed no listening). Raw WER is the
primary metric; `delta_*` vs the per-source ASR baseline are provided for context
only and are NOT subtracted.

## Table

| source | system | WER | CER | S/D/I | ref words | delta_WER | delta_CER |
|---|---|---|---|---|---|---|---|
| hist | SOURCE (ASR baseline) | 0.097 | 0.021 | 3/0/0 | 31 | — | — |
| hist | RVC GermanLecturerRVC | 0.065 | 0.021 | 2/0/0 | 31 | −0.032 | +0.000 |
| hist | Seed-VC 1.0_100_0.7 | **0.000** | **0.000** | 0/0/0 | 31 | **−0.097** | −0.021 |
| hist | Seed-VC 1.0_64_1.5 | 0.032 | 0.011 | 1/0/0 | 31 | −0.065 | −0.011 |
| test01 | SOURCE (ASR baseline) | 0.000 | 0.000 | 0/0/0 | 24 | — | — |
| test01 | RVC GermanLecturerRVC | 0.167 | 0.052 | 2/0/2 | 24 | +0.167 | +0.052 |
| prepared | SOURCE (ASR baseline) | 0.030 | 0.014 | 1/0/0 | 33 | — | — |
| prepared | RVC_Audit8 harvest p0 | 0.061 | 0.019 | 2/0/0 | 33 | +0.030 | +0.005 |
| prepared | RVC_Audit8 harvest p2 | 0.061 | 0.023 | 2/0/0 | 33 | +0.030 | +0.009 |
| prepared | RVC_Audit8 rmvpe p0 | 0.061 | 0.014 | 2/0/0 | 33 | +0.030 | +0.000 |
| prepared | RVC_Audit8 rmvpe p2 | 0.061 | 0.014 | 2/0/0 | 33 | +0.030 | +0.000 |
| prepared | Seed-VC 1.0_30_0.7 baseline | 0.758 | 0.528 | 17/4/4 | 33 | +0.727 | +0.514 |

## Reading

- **hist — Seed-VC 1.0_100_0.7 (100 steps): WER 0.000.** Against the human-verified
  reference this is a perfect content match (ASR-measured). The previous
  ASR-consensus reference penalized it for "das"/"Bla" — which the human confirmed
  are exactly what the source says. This is the single best content result of the
  evaluation.
- **hist — Seed-VC 1.0_64_1.5:** 1 sub ("die"→"das") → WER 0.032, also better than
  the source's own ASR baseline (−0.065).
- **hist — RVC:** 2 subs ("die"→"das", "Sachen"→"Drachen") → WER 0.065; RVC is
  content-accurate on "Bla und Bla" (it fixed what turbo misheard) but corrupts
  "Sachen"→"Drachen".
- **prepared — RVC_Audit8 (all 4 configs):** WER 0.061. The human reference
  ("die Seiten gereiht hat ... zu reihen") matches what RVC's output actually
  contains on "gereiht", but all four configs still say "diese" (not "die") and
  misrender the final verb ("treiben"/"primen"/"reimen" instead of "reihen") →
  2 subs. The source's own ASR baseline is 0.030 (its only error is "gerät" for
  "gereiht"), so RVC is now Δ+0.030, i.e. slightly worse than the source at the
  ASR level — a correction of the previous package's "ΔWER 0.000" reading.
- **prepared — Seed-VC baseline:** WER 0.758 (17 subs, 4 dels, 4 ins of 33 words) —
  content largely destroyed ("Ausbringungsgungle ... Sollte eine Exakt").
- **test01 — RVC:** 0.167 (2 subs + 2 ins; "die auf dem Well" artifact and a
  duplicated clause), against a reference that needed no human correction.

## Caveats

- References are now [HUMAN-VERIFIED]; the 6 disputed tokens were resolved by
  listening, and no unresolved tokens remain (the 3-way year split resolved to 1972;
  "gerät hat" resolved to "gereiht hat"; "Blah" resolved to "Bla").
- Case- and punctuation-normalized (German umlauts → ae/oe/ue). The odd
  grammatical form "das spezifische Technik" in hist is preserved exactly as spoken.
- The two byte-identical Seed-VC copies are excluded from this table by design
  (see `03_PROVENANCE/seedvc_output_provenance.md`).