# HUMAN_REVIEW_TASKS.md — COMPLETED

**All 6 tasks were resolved by the author's listening on 2026-08-20.** The final
decisions are applied to `01_TRANSCRIPTS/source_ground_truth_review.csv` and
reflected in every table of `00_REPORT/FINAL_STS_METRICS_REPORT.md` and
`04_CONTENT/content_metrics_FINAL.csv`. This file is kept as the record of the
tasks and their resolutions.

| # | File | Timestamp (in source) | Question | Options | Response (HUMAN-VERIFIED) |
|---|---|---|---|---|---|
| 1 | `hist__B_jahr_1972-1970-1901__9.4-11.4s.wav` | 9.98–10.82 s | Which number does the author say after "Euler wurde"? | 1972 / 1970 / 1901 / other | **1972** |
| 2 | `hist__A_die-das-spezifische__4.0-6.0s.wav` | 4.70–4.92 s | "…verwenden wir ___ spezifische Technik…" — "die" or "das"? | die / das | **"das"** (preserved as spoken, no correction) |
| 3 | `hist__C_uebertragen__12.8-15.0s.wav` | 13.36–14.26 s | "…dieses Wissen ___ und er hat uns…" — "übertragen" or "übertagen"? | übertragen / übertagen | **übertragen** |
| 4 | `hist__D_blah-blah__16.2-19.4s.wav` | 16.78–18.70 s | "…Sachen wie ___ und ___ gegeben." — "Blah" or "Bla"? | Blah / Bla | **"Bla und Bla"** |
| 5 | `prepared__A_diese-seiten-geraet-hat__4.4-7.0s.wav` | 4.96–6.48 s | (a) "die" or "diese" Seiten? (b) What verb: all ASR models hear "gerät hat" but the PageRank context suggests "gerankt hat"? | (a) die/diese (b) gerät / gerankt / other | **(a) "die" (b) "gereiht hat"** |
| 6 | `prepared__B_zu-reihen-rein__13.0-17.4s.wav` | 13.52–16.96 s | "…um Seiten zu ___ und ein bisschen…" — "reihen" or "rein"? | reihen / rein | **reihen** |

## Optional listening (no metric impact)

- `prepared__A...` — also confirms whether the source really ends at
  "...übertrieben kitschig" (the small ASR pass hallucinated a sentence repetition;
  `CONFIG_MANIFEST.txt` agrees with the clip ending).