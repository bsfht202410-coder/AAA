# transcript_verification.md

Verification protocol applied to the three source recordings (author's voice) that
feed the common Chapter-7 metrics. This addresses the previous package's key
limitation: "ASR-derived transcripts, not manual ground truth".

## Protocol

Three independent ASR passes on the identical audio, fixed protocol
(`language='de'`, `beam_size=5`, `temperature=0.0`, `vad_filter=False`):

| pass | model | source of transcript |
|---|---|---|
| 1 | faster-whisper `large-v3-turbo` | `02_CONTENT/transcripts_all.json` (word timestamps) |
| 2 | faster-whisper `medium` | `01_TRANSCRIPTS/asr_crosscheck_medium.json` |
| 3 | faster-whisper `small` | `01_TRANSCRIPTS/asr_pass3_small.json` |

Word-by-word comparison via Levenshtein alignment onto the turbo segmentation
(`06_REPRODUCIBILITY/scripts/transcript_review.py`). Every token where the models
disagree is flagged with timestamps and exported for listening
(`01_TRANSCRIPTS/HUMAN_REVIEW/`, `HUMAN_REVIEW_REQUIRED.md`). No unclear word is
silently guessed; ambiguous tokens keep the majority value for WER computation and
are marked `[UNRESOLVED]` where no majority exists.

## Result per source

### hist — seedvc_hist_lecturer.wav (20.1 s) — 31 reference tokens

Agreement 27/31 tokens (3-of-3). Disputed:

| token | turbo | medium | small | proposal |
|---|---|---|---|---|
| 4.70-4.92 s "die/das" | die | die | das | die (2v1) |
| 9.98-10.82 s year | 1972 | 1970 | 1901 | 1972 **[UNRESOLVED, 3-way split]** |
| 13.36-14.26 s "übertragen" | übertragen | übertragen | übertagen | übertragen (2v1) |
| 16.78-17.68 s "Blah" | Blah | Bla | Blah | Blah (2v1) |
| 18.14-18.70 s "Blah" | Blah | Bla | Blah | Blah (2v1) |

Note: small additionally hallucinated "sitzig" adjacent to the year token.

### test01 — seedvc_test01_lecturer.wav (12.0 s) — 24 reference tokens

**24/24 agreement across all three models.** No human review required.
`"Fahrradfahrer sollten auf der Straße verboten sein, nur Autos sollten auf der
Straße fahren dürfen, weil Autos sind halt besser geeignet für die Straßen."`

### prepared — source_mine_prepared_48k.wav (21.2 s) — 33 reference tokens

Agreement 31/33 (3-of-3). Disputed:

| token | turbo | medium | small | proposal |
|---|---|---|---|---|
| 4.96-5.22 s "die/diese Seiten" | die | diese | diese | diese (2v1) |
| 13.52-16.96 s "reihen/rein" | reihen | rein | rein | rein (2v1; German verb for ranking = "reihen") |

Additional findings:

- 5.64-6.48 s: all three models hear **"gerät hat"** (agreement 3-of-3). The
  PageRank context ("Google ... seine Seiten ... gerankt hat") suggests the intended
  word may be **"gerankt"**; this is a semantic ambiguity, not an ASR disagreement,
  and is flagged for the author's listening (clip `prepared__A...`).
- The small pass appended a verbatim repetition of the first sentence at the end
  (hallucination artifact). The project's `CONFIG_MANIFEST.txt` (line 24) documents
  the prepared clip's content ending at "...übertrieben kitschig", confirming the
  repetition is an ASR artifact.

## Status — COMPLETED (2026-08-20)

- [x] AUTHOR LISTENING PERFORMED — all 6 clips in `HUMAN_REVIEW/` resolved:
      1. year = **1972** (3-way ASR split resolved)
      2. article = **"das spezifische Technik"** (preserved as spoken, NOT corrected to "die")
      3. verb = **übertragen**
      4. final phrase = **"Bla und Bla"** (turbo/small "Blah" rejected)
      5. prepared phrase = **"die Seiten gereiht hat"** (all three ASR passes misheard "gerät")
      6. prepared verb = **reihen** (not "rein")
- [x] Decisions applied to `source_ground_truth_review.csv` (confidence =
      HUMAN-VERIFIED, human_review_required = NO) via
      `06_REPRODUCIBILITY/scripts/apply_human_decisions.py`.
- [x] `wer_cer_final.py` re-run — `content_metrics_FINAL.csv` reflects the
      human-verified reference (changes: hist baseline 0.000→0.097; Seed-VC 100-step
      hist 0.097→0.000; RVC hist 0.097→0.065; prepared baseline 0.061→0.030;
      RVC prepared ΔWER 0.000→+0.030; Seed-VC prepared 0.818→0.758).