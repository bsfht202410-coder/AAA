# similarity_summary_FINAL.md

CAMPPlus (funasr cn_common, 192-d) common protocol. Target centroid = normalized
mean of 10 unique target recordings (deduplicated; see target_reference_set_FINAL.csv).

Leave-one-out genuine-target baseline: n=10, mean=0.9469, std=0.0196, min=0.9202,
max=0.9743
(No human-recognition threshold is derived from these values.)

Source-to-target baseline (3 sources vs centroid):
- hist  0.8802
- test01 0.9187
- prepared 0.8544

## Methodological qualification

The common target-speaker centroid consists of authentic target-speaker speech, but
the selected recordings are **not an independently held-out evaluation corpus**
relative to all RVC training material: every recording derives from the four
lecturer lessons, and slices of the same lessons form the training sets of
`RVC_Audit8` and `GermanLecturerRVC` (several centroid files are byte-identical to
training slices). The similarity results are therefore used **only as descriptive
embedding measurements** (how close the converted voice sits to the target centroid
in CAMPPlus embedding space) and **not as estimates of generalization performance**
of any conversion system. No claim of "identity match" or of generalization is made
from these values.

All numerical values in this file are unchanged from the FINAL calculation
(no CAMPPlus re-run; the human-verified transcripts affect only WER/CER content
metrics).