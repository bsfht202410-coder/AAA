"""provenance_check.py - byte-level provenance audit of every Seed-VC output.

Every claimed Seed-VC output is hashed (SHA-256) together with its claimed source
and the reference used. A 'valid conversion' requires the output to differ from the
source (byte-identical output = the pipeline did not run / produced a copy, hence
INVALID as evidence). Results are written to 03_PROVENANCE/seedvc_output_provenance.md.
"""
import hashlib
import os

STAGE = r"C:\AI\Beatrice\output\sts_final_metrics_stage\sts_chapter7_common_metrics_FINAL"
SV = r"C:\AI\Beatrice\output\seedvc_validation"
MT = r"C:\AI\Beatrice\output\seedvc_validation\matched_test"
TMP = r"C:\Users\pcai\AppData\Local\Temp\opencode"

FILES = [
    ("source", "seedvc_hist_lecturer.wav", os.path.join(SV, "seedvc_hist_lecturer.wav")),
    ("source", "seedvc_test01_lecturer.wav", os.path.join(SV, "seedvc_test01_lecturer.wav")),
    ("source", "source_mine_prepared_48k.wav", os.path.join(MT, "source_mine_prepared_48k.wav")),
    ("claimed_output", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav",
     os.path.join(SV, "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav")),
    ("claimed_output", "vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav",
     os.path.join(SV, "vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav")),
    ("claimed_output", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav",
     os.path.join(SV, "variants", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav")),
    ("claimed_output", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav",
     os.path.join(SV, "variants", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav")),
    ("claimed_output", "result_baseline_newrec.wav", os.path.join(MT, "result_baseline_newrec.wav")),
    ("seedvc_reference", "seedvc_ref_lecturer.wav", os.path.join(TMP, "seedvc_ref_lecturer.wav")),
    ("excluded_reference", "target_gt_lecturer_mono.wav", os.path.join(MT, "target_gt_lecturer_mono.wav")),
]

# claimed source of each claimed output (for the byte-identical test)
CLAIMED_SOURCE = {
    "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav": "seedvc_hist_lecturer.wav",
    "vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav": "seedvc_test01_lecturer.wav",
    "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav": "seedvc_hist_lecturer.wav",
    "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav": "seedvc_hist_lecturer.wav",
    "result_baseline_newrec.wav": "source_mine_prepared_48k.wav",
}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    hashes = {name: sha256(path) for _k, name, path in FILES}
    out = ["# seedvc_output_provenance.md",
           "",
           "SHA-256 audit of every claimed Seed-VC output vs its claimed source. "
           "A claimed output is a **valid conversion** only if it differs from the source "
           "at the byte level; byte-identical files are excluded from all metric tables.",
           "",
           "| file | sha256 | source_file | byte_identical_to_source | valid_conversion |",
           "|---|---|---|---|---|"]
    for kind, name, path in FILES:
        if kind != "claimed_output":
            continue
        src = CLAIMED_SOURCE[name]
        identical = hashes[name] == hashes[src]
        out.append(f"| {name} | {hashes[name]} | {src} | {'YES' if identical else 'NO'} | "
                   f"{'NO - byte-identical copy' if identical else 'YES'} |")
    out += ["",
            "## Genuine Seed-VC outputs (used in metrics)",
            "",
            "| file | sha256 | identical_to_source |",
            "|---|---|---|"]
    for name in ["vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav",
                 "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav",
                 "result_baseline_newrec.wav"]:
        src = CLAIMED_SOURCE[name]
        out.append(f"| {name} | {hashes[name]} | {hashes[name] == hashes[src]} |")
    out += ["",
            "## Excluded / reference files",
            "",
            "| file | sha256 |",
            "|---|---|"]
    for kind, name, _p in FILES:
        if kind != "claimed_output":
            out.append(f"| {name} | {hashes[name]} |")
    out += ["",
            "## Conclusion",
            "",
            "- `vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav` == `seedvc_hist_lecturer.wav` "
            "(byte-identical): the pipeline wrote a copy of the source, not a conversion. "
            "The previous package's `seedvc_metrics.txt` values (0.9497 / 0.9463) measured "
            "source-vs-lecturer, NOT Seed-VC output, and are excluded from the FINAL report.",
            "- `vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav` == `seedvc_test01_lecturer.wav` "
            "(byte-identical): same conclusion.",
            "- The three retained outputs (100-step, 64-step/t=1.5, prepared baseline) differ from "
            "their sources at the byte level and are valid conversion artifacts.",
            "- `seedvc_ref_lecturer.wav` (23.33 s) and `target_gt_lecturer_mono.wav` are NOT "
            "duplicates of any target-reference or training slice and are excluded from the "
            "target centroid by design (known-use rules in target_reference_set_FINAL.csv)."]
    with open(os.path.join(STAGE, "03_PROVENANCE", "seedvc_output_provenance.md"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(out))
    print("wrote seedvc_output_provenance.md")
    for name in CLAIMED_SOURCE:
        print(f"{name}: identical_to_source={hashes[name] == hashes[CLAIMED_SOURCE[name]]}")


if __name__ == "__main__":
    main()