"""campplus_sim_final.py - FINAL common speaker-similarity protocol for Chapter 7.

CORRECTIONS vs the previous common_metrics package:
  1. Deduplicated target set. SHA-256 sweep of 206 files showed that ALL 5
     identity-study refs and ALL 3 holdouts are byte-identical to
     GermanLecturerRVC training slices, and the previous package's
     'train_slice_audio1' was the SAME recording as prof_ref_01. The FINAL set
     therefore contains 10 UNIQUE recordings: prof_ref_01..05 (one representation
     per duplicated slice), prof_holdout_01..03, plus two unique slices
     (audio2.w_00244, audio3.w_00235).
  2. Removed the two byte-identical Seed-VC copies (provenance section) from EVAL.
  3. Added similarity_to_source and delta_similarity_vs_source columns.

Pipeline identical to the previous package: CAMPPlus (funasr cn_common, 192-d),
mel-80 @ 16 kHz, L2-normalized embeddings, centroid = normalized mean. LOO stats
reported as n/mean/std/min/max with NO human-recognition threshold.

Run with the seed-vc venv from tools/seed-vc/repo.
"""
import csv
import hashlib
import json
import os

import librosa
import numpy as np
import soundfile as sf
import torch

REPO = r"C:\AI\Beatrice\tools\seed-vc\repo"
os.chdir(REPO)
import sys
sys.path.insert(0, REPO)
from modules.campplus.DTDNN import CAMPPlus  # noqa: E402

OUT = r"C:\AI\Beatrice\output\sts_final_metrics_stage\sts_chapter7_common_metrics_FINAL"
SV = r"C:\AI\Beatrice\output\seedvc_validation"
RV = r"C:\AI\Beatrice\output\rvc_validation"
MT = r"C:\AI\Beatrice\output\seedvc_validation\matched_test"
FIT = r"C:\AI\Beatrice\output\diag\final_identity_test"
TR = r"C:\AI\Beatrice\datasets\GermanLecturer_training\GermanLecturer"

CKPT = os.path.join(REPO, "checkpoints", "models--funasr--campplus", "snapshots",
                    "e4b6ede7ce16997aff4ae69fbca1f0175e2afede", "campplus_cn_common.bin")

# (reference_id, filename, path, known_use_in_training, known_use_as_seedvc_prompt,
#  known_use_as_xtts_reference, known_use_as_previous_metric_reference, included_in_centroid, reason)
TARGETS = [
    ("prof_ref_01", "prof_ref_01.wav", os.path.join(FIT, "target_professor", "prof_ref_01.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "byte-identical to training slice GermanLecturer_audio1.w_00137.wav (sha 23db66a9...); kept as the single representation of that recording"),
    ("prof_ref_02", "prof_ref_02.wav", os.path.join(FIT, "target_professor", "prof_ref_02.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "byte-identical to training slice GermanLecturer_audio1.w_00039.wav; kept as the single representation"),
    ("prof_ref_03", "prof_ref_03.wav", os.path.join(FIT, "target_professor", "prof_ref_03.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "byte-identical to training slice GermanLecturer_audio2.w_00047.wav; kept as the single representation"),
    ("prof_ref_04", "prof_ref_04.wav", os.path.join(FIT, "target_professor", "prof_ref_04.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "byte-identical to training slice GermanLecturer_audio3.w_00218.wav (sha 7e90e5ae...); kept as the single representation"),
    ("prof_ref_05", "prof_ref_05.wav", os.path.join(FIT, "target_professor", "prof_ref_05.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "byte-identical to training slice GermanLecturer_audio4.w_00146.wav; kept as the single representation"),
    ("prof_holdout_01", "prof_holdout_01.wav", os.path.join(FIT, "prof_holdout", "prof_holdout_01.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "byte-identical to training slice GermanLecturer_audio1.w_00002.wav; kept as the single representation"),
    ("prof_holdout_02", "prof_holdout_02.wav", os.path.join(FIT, "prof_holdout", "prof_holdout_02.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "byte-identical to training slice GermanLecturer_audio3.w_00044.wav; kept as the single representation"),
    ("prof_holdout_03", "prof_holdout_03.wav", os.path.join(FIT, "prof_holdout", "prof_holdout_03.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "byte-identical to training slice GermanLecturer_audio4.w_00295.wav; kept as the single representation"),
    ("train_slice_audio2_w244", "GermanLecturer_audio2.w_00244.wav",
     os.path.join(TR, "GermanLecturer_audio2.w_00244.wav"),
     "YES", "NO", "NO", "YES", "YES",
     "kept training slice (196 kept), 9.86 s, unique content (not duplicate of any identity-study clip)"),
    ("train_slice_audio3_w235", "GermanLecturer_audio3.w_00235.wav",
     os.path.join(TR, "GermanLecturer_audio3.w_00235.wav"),
     "YES", "NO", "NO", "NO", "YES",
     "kept training slice (196 kept), 11.52 s, unique content (sha d3190901...), NEW in FINAL set"),
]

# (label, source_id, system, model, path)
EVAL = [
    ("hist_source", "hist", "source", "none (author recording)", os.path.join(SV, "seedvc_hist_lecturer.wav")),
    ("hist_rvc", "hist", "RVC", "GermanLecturerRVC (e190)", os.path.join(RV, "rvc_hist_lecturer.wav")),
    ("test01_source", "test01", "source", "none (author recording)", os.path.join(SV, "seedvc_test01_lecturer.wav")),
    ("test01_rvc", "test01", "RVC", "GermanLecturerRVC (e190)", os.path.join(RV, "rvc_test01_lecturer.wav")),
    ("prepared_source", "prepared", "source", "none (author recording)", os.path.join(MT, "source_mine_prepared_48k.wav")),
    ("prepared_rvc_h0", "prepared", "RVC", "RVC_Audit8 e800 harvest p0", os.path.join(RV, "rvc_harvest_p0.wav")),
    ("prepared_rvc_h2", "prepared", "RVC", "RVC_Audit8 e800 harvest p2", os.path.join(RV, "rvc_harvest_p2.wav")),
    ("prepared_rvc_r0", "prepared", "RVC", "RVC_Audit8 e800 rmvpe p0", os.path.join(RV, "rvc_rmvpe_p0.wav")),
    ("prepared_rvc_r2", "prepared", "RVC", "RVC_Audit8 e800 rmvpe p2", os.path.join(RV, "rvc_rmvpe_p2.wav")),
    ("prepared_seedvc", "prepared", "Seed-VC", "1.0_30_0.7 baseline", os.path.join(MT, "result_baseline_newrec.wav")),
    ("hist_seedvc_100st", "hist", "Seed-VC variant", "1.0_100_0.7 (100 steps)", os.path.join(SV, "variants", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav")),
    ("hist_seedvc_64t15", "hist", "Seed-VC variant", "1.0_64_1.5 (64 steps, t=1.5)", os.path.join(SV, "variants", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav")),
]

device = "cuda" if torch.cuda.is_available() else "cpu"
model = CAMPPlus(feat_dim=80, embedding_size=192)
model.load_state_dict(torch.load(CKPT, map_location="cpu"))
model.eval().to(device)


def embed(path):
    x, sr = sf.read(path, dtype="float32", always_2d=False)
    if sr != 16000:
        x = librosa.resample(x, orig_sr=sr, target_sr=16000).astype(np.float32)
    spec = librosa.stft(x, n_fft=512, hop_length=160, win_length=512, center=True)
    mag = np.abs(spec)
    mel = librosa.filters.mel(sr=16000, n_fft=512, n_mels=80, fmin=0, fmax=8000)
    m = (mel @ mag).T
    m = np.log(np.clip(m, 1e-5, None))
    t = torch.from_numpy(m[None]).float().to(device)
    with torch.no_grad():
        e = model(t)[0].cpu().numpy()
    return e / (np.linalg.norm(e) + 1e-9)


def cos(a, b):
    return float(np.dot(a, b))


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    tgt_emb = {}
    rows = []
    for rid, fname, path, tr, sv_p, xt, prev, inc, reason in TARGETS:
        d = sf.info(path)
        rows.append({
            "reference_id": rid, "filename": fname, "original_path": path,
            "duration_s": round(d.frames / d.samplerate, 3), "sha256": sha256(path),
            "known_use_in_training": tr, "known_use_as_seedvc_prompt": sv_p,
            "known_use_as_xtts_reference": xt, "known_use_as_previous_metric_reference": prev,
            "included_in_centroid": inc, "reason": reason,
        })
        tgt_emb[rid] = embed(path)
    with open(os.path.join(OUT, "02_SIMILARITY", "target_reference_set_FINAL.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    names = [r["reference_id"] for r in rows]
    cent = sum(tgt_emb[n] for n in names)
    cent = cent / np.linalg.norm(cent)
    loo = {n: cos(tgt_emb[n],
                  (sum(tgt_emb[m] for m in names if m != n) / np.linalg.norm(
                      sum(tgt_emb[m] for m in names if m != n)))) for n in names}

    src_emb = {}
    sim_rows = [["source_id", "system", "model", "output_wav",
                 "campplus_similarity_to_target_centroid", "similarity_to_source",
                 "delta_similarity_vs_source", "duration_s", "note"]]
    for label, sid, system, mdl, path in EVAL:
        e = embed(path)
        if system == "source":
            src_emb[sid] = e
        d = sf.info(path)
        s2s = round(cos(e, src_emb[sid]), 4) if sid in src_emb and system != "source" else ""
        sim_rows.append([sid, system, mdl, os.path.basename(path),
                         round(cos(e, cent), 4), s2s,
                         round(cos(e, cent) - cos(src_emb[sid], cent), 4) if sid in src_emb and system != "source" else "",
                         round(d.frames / d.samplerate, 2), ""])
    with open(os.path.join(OUT, "02_SIMILARITY", "common_speaker_similarity_FINAL.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(sim_rows[0])
        w.writerows(sim_rows[1:])

    loo_v = list(loo.values())
    summary = (
        "# similarity_summary_FINAL.md\n\n"
        "CAMPPlus (funasr cn_common, 192-d) common protocol. Target centroid = normalized mean "
        "of %d unique target recordings (deduplicated; see target_reference_set_FINAL.csv).\n\n"
        "Leave-one-out genuine-target baseline: n=%d, mean=%.4f, std=%.4f, min=%.4f, max=%.4f\n"
        "(No human-recognition threshold is derived from these values.)\n\n"
        "Source-to-target baseline (3 sources vs centroid):\n"
        "- hist  %.4f\n- test01 %.4f\n- prepared %.4f\n"
        % (len(names), len(loo_v), np.mean(loo_v), np.std(loo_v), min(loo_v), max(loo_v),
           cos(src_emb["hist"], cent), cos(src_emb["test01"], cent), cos(src_emb["prepared"], cent))
    )
    with open(os.path.join(OUT, "02_SIMILARITY", "similarity_summary_FINAL.md"), "w",
              encoding="utf-8") as f:
        f.write(summary)

    with open(os.path.join(OUT, "02_SIMILARITY", "embeddings_FINAL.json"), "w", encoding="utf-8") as f:
        json.dump({"model": "CAMPPlus cn_common 192-d", "ckpt": CKPT, "n_targets": len(names),
                   "loo_cosine": loo, "target_embeddings": {n: tgt_emb[n].tolist() for n in names}},
                  f)
    print("LOO: n=%d mean=%.4f std=%.4f min=%.4f max=%.4f" % (
        len(loo_v), np.mean(loo_v), np.std(loo_v), min(loo_v), max(loo_v)))
    print("wrote target_reference_set_FINAL.csv + common_speaker_similarity_FINAL.csv + similarity_summary_FINAL.md")


if __name__ == "__main__":
    main()