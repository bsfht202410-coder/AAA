# FINAL_STS_METRICS_REPORT.md — Chapter 7 Common Metrics (Locked)

Date: 2026-08-20. Package: `sts_chapter7_common_metrics_LOCKED.zip`.
Supersedes `sts_chapter7_common_metrics_FINAL.zip` (pre-human-verification) and the
earlier `sts_chapter7_common_metrics.zip` / `sts_chapter7_evidence.zip` metric values.
Tags: [MEASURED] directly computed from audio artifacts; [DERIVED] aggregates;
[HUMAN-VERIFIED] author-confirmed by listening; [QUALITATIVE] contextual
observations; [UNRESOLVED] not determinable from evidence.

---

## Setup (unchanged)

- **RVC (large):** `RVC_Audit8` — 513 slices / 31.59 min / trained 545.9 min.
- **RVC (small):** `GermanLecturerRVC` — 459 slices / 22.40 min / trained 118.9 min.
- **Seed-VC:** the two `1.0_30_0.7` outputs are byte-identical copies of their
  sources [MEASURED, SHA-256] and are **excluded** from all metric tables
  (`03_PROVENANCE/seedvc_output_provenance.md`). Only 3 genuine Seed-VC outputs
  are evaluated.
- **Transcripts:** [HUMAN-VERIFIED] — consensus of 3 ASR passes (turbo/medium/small)
  plus direct listening resolution of all 6 ambiguous segments (2026-08-20):
  year=`1972`; article=`"das spezifische Technik"` (preserved as spoken);
  verb=`übertragen`; final phrase=`"Bla und Bla"`; prepared phrase=
  `"die Seiten gereiht hat"`; prepared verb=`reihen`. `test01` needed no listening
  (3/3 verbatim agreement). No unresolved tokens remain.
- **Target centroid:** 10 unique recordings, SHA-256-deduplicated over 206
  candidates (`02_SIMILARITY/target_reference_set_FINAL.csv`).

---

## A. Content preservation (WER/CER vs HUMAN-VERIFIED reference) [MEASURED, HUMAN-VERIFIED]

| source | system | WER | CER | S/D/I | delta_WER vs source |
|---|---|---|---|---|---|
| hist | RVC GermanLecturerRVC | 0.065 | 0.021 | 2/0/0 | −0.032 |
| hist | Seed-VC 100-step | **0.000** | **0.000** | 0/0/0 | **−0.097** |
| hist | Seed-VC 64-step t=1.5 | 0.032 | 0.011 | 1/0/0 | −0.065 |
| test01 | RVC GermanLecturerRVC | 0.167 | 0.052 | 2/0/2 | +0.167 |
| prepared | RVC_Audit8 (4 configs) | 0.061 | 0.014–0.023 | 2/0/0 | +0.030 |
| prepared | Seed-VC baseline | 0.758 | 0.528 | 17/4/4 | +0.727 |

ASR source baselines [DERIVED]: hist 0.097 (turbo misheard "die/Blah" for
"das/Bla"), test01 0.000, prepared 0.030 (turbo misheard "gerät" for "gereiht").

**Finding A1:** Seed-VC 1.0_100_0.7 on hist is a **perfect content match**
(WER 0.000) against the human-verified reference — the best content result in the
study. With the previous ASR-consensus reference it scored 0.097; the correction
is entirely due to the human decisions ("das", "Bla") [MEASURED].

**Finding A2:** Seed-VC 1.0_64_1.5 (0.032) and RVC hist (0.065) are both better
than the source's own ASR baseline (−0.065 / −0.032), i.e. they contain fewer
ASR-measurable errors than the turbo transcription of the source itself.

**Finding A3:** On prepared, all four RVC_Audit8 configs reach WER 0.061 —
content-preserving, but Δ+0.030 vs the source's 0.030 baseline (previous package's
"ΔWER 0.000, indistinguishable from source" reading is corrected: with the
human-verified "gereiht"/"reihen" reference, RVC carries 2 subs vs the source's 1).

**Finding A4:** Seed-VC baseline destroys the prepared content (WER 0.758).

## B. Target similarity (CAMPPlus vs 10-clip lecturer centroid) [MEASURED]

Unchanged from the FINAL calculation (no re-run; transcripts do not affect
embeddings). Genuine-target LOO: n=10, mean=0.9469, std=0.0196, min=0.9202,
max=0.9743 [DERIVED]. Sources: hist 0.8802, test01 0.9187, prepared 0.8544.

| source | system | sim to centroid | sim to source | delta vs source |
|---|---|---|---|---|
| hist | RVC GermanLecturerRVC | 0.8631 | 0.7142 | −0.0171 |
| hist | Seed-VC 100-step | 0.8964 | 0.9914 | +0.0162 |
| hist | Seed-VC 64-step t=1.5 | 0.8776 | 0.9886 | −0.0026 |
| test01 | RVC GermanLecturerRVC | 0.7605 | 0.6706 | −0.1583 |
| prepared | RVC_Audit8 h0 | 0.9246 | 0.9203 | +0.0702 |
| prepared | RVC_Audit8 h2 | **0.9565** | 0.8839 | **+0.1022** |
| prepared | RVC_Audit8 r0 | 0.9122 | 0.9295 | +0.0578 |
| prepared | RVC_Audit8 r2 | **0.9540** | 0.8805 | +0.0996 |
| prepared | Seed-VC baseline | 0.9178 | 0.7943 | +0.0634 |

**Finding B1:** RVC_Audit8's prepared outputs (0.912–0.957) sit at/above the
source (0.854) and inside/above the genuine-target LOO band (min 0.9202) [MEASURED].
No human-perception threshold is claimed (see F).

**Finding B2:** GermanLecturerRVC on test01 moves away from the target (−0.158).

## C. Delta movement (toward / away from target) [DERIVED]

- Largest positive target movement: RVC_Audit8 on prepared (+0.058…+0.102).
- Largest negative: GermanLecturerRVC on test01 (−0.158).
- Seed-VC on hist: negligible movement (+0.016 / −0.003), similarity_to_source
  ≈ 0.99 — the voice was barely transformed on this sentence, yet its content is
  the most accurate (A1/A2): Seed-VC's hist outputs are near-copies of the source
  in both content and embedding space.

## D. Smaller vs larger RVC model

Not directly rankable: the two RVC models were evaluated on **different sentences**
(RVC_Audit8 on the 33-word prepared text; GermanLecturerRVC on the 31/24-word hist
and test01 texts). Cross-sentence WER/CAMPPlus comparisons are confounded.
Within-sentence: RVC_Audit8 (larger, 513 slices / 31.6 min) achieves ΔWER +0.030
and positive target deltas on prepared; GermanLecturerRVC (smaller, 459 slices /
22.4 min) achieves ΔWER −0.032 on hist (better than the source's ASR) but +0.167
and −0.158 on test01. A "larger RVC is better" claim would require identical
source sentences — [UNRESOLVED] without a new experiment (out of scope).

## E. Seed-VC claim

The prior claim that Seed-VC rivals or beats RVC on the lecturer similarity is
**not supported**, and the corrected content numbers do not rescue it [MEASURED]:

1. The two headline Seed-VC values (0.9497 / 0.9463 in `seedvc_metrics.txt`) were
   computed on byte-identical copies of the source — they measure
   source-vs-lecturer, not Seed-VC output. Excluded.
2. Genuine Seed-VC on hist: similarity 0.878–0.896 ≈ source's own 0.8802, with
   similarity_to_source ≈ 0.99 → **negligible voice transformation toward the
   target**; the perfect WER (0.000) reflects content fidelity, not identity change.
3. Genuine Seed-VC on prepared: content destroyed (WER 0.758); similarity 0.9178
   comparable to RVC_Audit8's 0.912–0.957 but with far worse content.

Conclusion: no evidence that Seed-VC provides better resemblance or better content
preservation than RVC in this setup. The best Seed-VC artifact (hist, 100-step) is
a near-verbatim content copy of the source with negligible voice transformation.

## F. Human-perception disclaimer

CAMPPlus cosine is an objective, model-based embedding similarity; it is **not** a
perceptual measure, and no threshold or "sounds like the same person" claim is
derived from it. Perceived identity can only be established by listening; the
listening that was performed (transcript verification) was about **content**, not
perceived speaker identity. No identity-listening experiment was run for this
package — perceptual identity comparisons remain future work.

## Methodological qualification (target centroid)

The common target-speaker centroid consists of authentic target-speaker speech, but
the selected recordings are **not an independently held-out evaluation corpus**
relative to all RVC training material: all recordings derive from the four lecturer
lessons, and slices of the same lessons form the training sets of `RVC_Audit8` and
`GermanLecturerRVC` (several centroid files are byte-identical to training slices).
The similarity results are therefore **descriptive embedding measurements only**,
**not estimates of generalization performance**, and no identity-match or
generalization claim is made from them.

---

## Corrections caused by the human-verified transcripts

1. **hist source ASR baseline: 0.000 → 0.097.** Turbo misheard "das" as "die" and
   "Bla und Bla" as "Blah und Blah". The human-verified reference uses the spoken
   forms; the source's own turbo transcript now carries 3 subs [MEASURED].
2. **Seed-VC 1.0_100_0.7 (hist): 0.097 → 0.000.** Its "das"/"bla bla" forms — which
   previously counted as errors — are exactly what the source says. Best content
   result of the study.
3. **Seed-VC 1.0_64_1.5 (hist): 0.065 → 0.032** (1 sub, "die"→"das").
4. **RVC hist: 0.097 → 0.065** (2 subs: "die"→"das", "Sachen"→"Drachen").
5. **prepared source ASR baseline: 0.061 → 0.030.** Only "gerät"→"gereiht" remains
   (all three ASR passes misheard the human-confirmed "gereiht").
6. **RVC_Audit8 prepared: ΔWER 0.000 → +0.030** (WER stays 0.061). The "ASR-
   indistinguishable from the source" reading of the previous package is corrected:
   with the verified reference ("die Seiten ... gereiht ... reihen"), RVC carries
   2 subs ("diese", and the final verb "treiben"/"primen"/"reimen") vs the source's 1.
7. **Seed-VC prepared baseline: 0.818 → 0.758** (same audio; reference change).
8. **test01: unchanged** (reference was already verbatim-agreed).

## Corrections carried over from the previous package (unchanged)

- Target centroid deduplication (8 identity-study clips were byte-identical
  training slices; 10 unique recordings now).
- `seedvc_metrics.txt` (0.9497/0.9463) measured the source, not Seed-VC — excluded.
- CAMPPlus LOO 0.9455 → 0.9469 with the corrected centroid.
- Identity-study integrity note: the identity study's "prof holdout" baseline clips
  are GermanLecturerRVC training slices [QUALITATIVE].

## Three strongest findings

1. [HUMAN-VERIFIED/MEASURED] Seed-VC 1.0_100_0.7 preserves the hist content
   perfectly (WER 0.000) but transforms the voice negligibly
   (sim_to_source 0.9914, Δsimilarity +0.016).
2. [MEASURED] RVC_Audit8 on prepared preserves content (WER 0.061, Δ+0.030) and
   moves the voice toward the lecturer centroid (Δ+0.058…+0.102, up to 0.9565) —
   the only configuration that simultaneously preserves content and moves toward
   the target.
3. [MEASURED] The two headline Seed-VC results were byte-identical source copies —
   invalid as evidence; GermanLecturerRVC's test01 output is the worst conversion
   (−0.158 similarity, +0.167 WER).

## Remaining evidence problems

1. **No identity-listening experiment** was run: perceived-speaker-identity
   comparisons (RVC vs Seed-VC vs source vs lecturer) are not [HUMAN-VERIFIED] and
   remain open questions for Chapter 7's perceptual claims [UNRESOLVED].
2. **Different source sentences per system** prevent a direct RVC-vs-Seed-VC and
   larger-vs-smaller-RVC comparison; only within-sentence statements are valid.
3. **Centroid is not held-out** (methodological qualification above): similarity
   values are descriptive, not generalization estimates.
4. **test01 RVC output** contains the "die auf dem Well" non-word artifact — a
   content failure worth an explicit sentence in the thesis.
5. The identity study's holdout interpretation (training-slice overlap) remains an
   integrity caveat for that separate study.

None of these prevent the package from being used in Chapter 7, provided the
wording follows the qualifications above (descriptive measurements, no
generalization/perceptual claims, byte-level provenance respected).