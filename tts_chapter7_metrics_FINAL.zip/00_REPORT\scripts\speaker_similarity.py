"""Descriptive CAMPPlus target-speaker similarity on EXISTING XTTS outputs.

Read-only with respect to the TTS project. Uses ONE fixed CAMPPlus
implementation: the official FunASR CAMPPlus model class
(funasr.models.campplus.model.CAMPPlus, Alibaba 3D-Speaker) with the
locally cached checkpoint `campplus_cn_common.bin` (192-dim embeddings,
16 kHz fbank input).

Pipeline:
1. Build target set: 8 authentic speaker clips from data/audio/reference/,
   SHA-256-verified unique, excluding the golden clip audio4_chunk_080.wav
   and the old thin golden clip audio2_chunk_082.wav (selection documented).
2. Target centroid = mean of L2-normalized embeddings, re-normalized.
3. Leave-one-out cosine statistics over the target set itself.
4. Cosine similarity of each existing XTTS benchmark output (and the
   optional emotion check) against the centroid.

Descriptive only: no threshold, no identity claim.
"""

import csv
import hashlib
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from funasr.models.campplus.model import CAMPPlus
from funasr.models.campplus.utils import extract_feature
from funasr.utils.load_utils import load_audio_text_image_video

ROOT = Path(r"C:\Users\pcai\Desktop\TTStest")
OUT = Path(r"C:\Users\pcai\AppData\Local\Temp\opencode\ch7final\02_SIMILARITY")

CKPT = Path(
    r"C:\Users\pcai\.cache\huggingface\hub\models--funasr--campplus\snapshots\fb71fe990cbf6031ae6987a2d76fe64f94377b7e\campplus_cn_common.bin"
)

# Authentic target clips: top-10 warmth/quality scan (voice_body_scan.json)
# minus the active golden clip (audio4_chunk_080) and the old thin golden
# clip (audio2_chunk_082). All from the same source recordings as the golden.
TARGET_CLIPS = [
    "audio1_chunk_046.wav",
    "audio3_chunk_074.wav",
    "audio3_chunk_026.wav",
    "audio1_chunk_079.wav",
    "audio1_chunk_045.wav",
    "audio2_chunk_058.wav",
    "audio1_chunk_081.wav",
    "audio2_chunk_052.wav",
]

# (category, run, wav, anomaly_status) - pass 2, existing files
BENCH = [
    ("short", 1, "lat15_short_1.wav", "ANOMALY_RETRY"),
    ("short", 2, "lat15_short_2.wav", "CLEAN"),
    ("short", 3, "lat15_short_3.wav", "ANOMALY_RETRY"),
    ("medium", 1, "lat15_medium_1.wav", "CLEAN"),
    ("medium", 2, "lat15_medium_2.wav", "CLEAN"),
    ("medium", 3, "lat15_medium_3.wav", "CLEAN"),
    ("long", 1, "lat15_long_1.wav", "CLEAN"),
    ("long", 2, "lat15_long_2.wav", "CLEAN"),
    ("long", 3, "lat15_long_3.wav", "CLEAN"),
]

PROBE = ("cli_interactive_20260811_231341.wav", "RETAINED_27.9S_GENERATION")

EMOTIONS = [
    ("neutral", "emotion_test_neutral.wav"),
    ("angry", "emotion_test_angry.wav"),
    ("sad", "emotion_test_sad.wav"),
    ("happy", "emotion_test_happy.wav"),
]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    print("loading CAMPPlus (funasr, campplus_cn_common.bin)")
    model = CAMPPlus()
    sd = torch.load(str(CKPT), map_location="cpu", weights_only=False)
    model.load_state_dict(sd)
    model.eval().cuda()

    def embed(path):
        wav = load_audio_text_image_video(str(path), fs=16000, audio_fs=16000, data_type="sound")
        speech, speech_lengths, speech_times = extract_feature([wav])
        with torch.no_grad():
            e = model.forward(speech.float().cuda())[0].detach().cpu().numpy().reshape(-1)
        e = e / (np.linalg.norm(e) + 1e-12)
        return e

    # 1. target set
    ref_dir = ROOT / "data/audio/reference"
    target = []
    for name in TARGET_CLIPS:
        p = ref_dir / name
        info = sf.info(str(p))
        target.append({
            "file": name, "sha256": sha256(p), "duration_s": round(info.duration, 3),
            "source": "data/audio/reference (authentic speaker recordings)",
            "selection": "top-10 warmth/quality scan minus golden clip (audio4_chunk_080) and old thin golden (audio2_chunk_082)",
        })
        print(f"target {name}: dur={info.duration:.1f}s")
    assert len(set(t["sha256"] for t in target)) == len(target), "target set not byte-unique"

    embs = np.stack([embed(ref_dir / t["file"]) for t in target])

    # 2. centroid + LOO
    norm = embs / np.linalg.norm(embs, axis=1, keepdims=True)
    centroid = norm.mean(axis=0)
    centroid = centroid / (np.linalg.norm(centroid) + 1e-12)
    loo = []
    for i in range(len(norm)):
        c = norm[np.arange(len(norm)) != i].mean(axis=0)
        c = c / (np.linalg.norm(c) + 1e-12)
        loo.append(float(np.dot(norm[i], c)))
    loo = np.array(loo)

    with open(OUT / "target_reference_set.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(target[0].keys()))
        w.writeheader()
        w.writerows(target)
    with open(OUT / "target_set_stats.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["statistic", "value"])
        w.writerow(["n", len(target)])
        w.writerow(["loo_mean", round(float(loo.mean()), 4)])
        w.writerow(["loo_std", round(float(loo.std()), 4)])
        w.writerow(["loo_min", round(float(loo.min()), 4)])
        w.writerow(["loo_max", round(float(loo.max()), 4)])
        w.writerow(["method", "cosine vs leave-one-out centroid of L2-normalized 192-dim CAMPPlus embeddings"])

    # 3. benchmark outputs
    rows = []
    for cat, run, wav, status in BENCH:
        p = ROOT / "outputs" / wav
        e = embed(p)
        sim = float(np.dot(e, centroid))
        rows.append({"file": wav, "category": cat, "pass": 2, "run": run,
                     "anomaly_status": status, "duration_s": round(sf.info(str(p)).duration, 3),
                     "campplus_similarity": round(sim, 4)})
        print(f"{wav}: sim={sim:.4f}")

    pp = ROOT / "data/audio/outputs" / PROBE[0]
    rows.append({"file": PROBE[0], "category": "probe_loop", "pass": "", "run": "",
                 "anomaly_status": PROBE[1], "duration_s": round(sf.info(str(pp)).duration, 3),
                 "campplus_similarity": round(float(np.dot(embed(pp), centroid)), 4)})

    with open(OUT / "xtts_speaker_similarity.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    # 4. emotion check
    erows = []
    for emo, wav in EMOTIONS:
        p = ROOT / "outputs" / wav
        erows.append({"emotion": emo, "file": wav,
                      "duration_s": round(sf.info(str(p)).duration, 3),
                      "campplus_similarity": round(float(np.dot(embed(p), centroid)), 4)})
    with open(OUT / "emotion_similarity.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(erows[0].keys()))
        w.writeheader()
        w.writerows(erows)

    # 5. summary per clean category
    for cat in ["short", "medium", "long"]:
        vals = [r["campplus_similarity"] for r in rows
                if r["category"] == cat and r["anomaly_status"] == "CLEAN"]
        if vals:
            print(f"CLEAN {cat}: n={len(vals)} mean={np.mean(vals):.4f} min={min(vals):.4f} max={max(vals):.4f}")
    print(f"LOO target: mean={loo.mean():.4f} std={loo.std():.4f} min={loo.min():.4f} max={loo.max():.4f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())