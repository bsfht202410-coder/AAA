# Final TTS Metrics Report — Chapter 7 supplementary evaluation

Supplementary, read-only evaluation of the **existing** Hand-15 XTTS
benchmark outputs (pass 1 + pass 2). No new speech was generated for this
package; no XTTS reruns, retraining, listener study, or parameter sweeps
were performed. All numbers below come from the artifacts already on disk
plus the two offline measurement scripts shipped in `00_REPORT/scripts/`.

Tagging: `[MEASURED]` = computed directly from artifacts;
`[DERIVED]` = derived by combining/comparing measured values;
`[QUALITATIVE]` = inspection-based; `[NOT SUPPORTED]` = no evidence basis.

---

## Methods (summary)

- ASR content metrics: faster-whisper `large-v3-turbo` (cached, CUDA fp16),
  beam 5, temperature 0, language `de`, no VAD. jiwer WER/CER vs. verified
  expected texts. See `01_CONTENT/xtts_content_metrics.csv`.
- Speaker similarity: official FunASR CAMPPlus (`campplus_cn_common.bin`,
  192-dim, 16 kHz) run offline on existing audio. L2-normalized embeddings;
  cosine vs. target-set centroid (8 authentic clips from
  `data/audio/reference/`, top-10 warmth/quality scan minus the golden clip
  `audio4_chunk_080.wav` and the old thin golden `audio2_chunk_082.wav`).
  Leave-one-out stats over the target set itself. Descriptive only — no
  threshold, no identity decision. See `02_SIMILARITY/`.
- Combined per-run table: `03_COMBINED/xtts_final_metrics.csv` (18 rows).

Known data limitation: pass-1 WAVs were overwritten by pass-2 (same
filenames; on-disk durations match the pass-2 log exactly, e.g. short_2
1.927 s on disk vs. 2.45 s in the pass-1 log). Pass-1 rows therefore carry
timing/anomaly from the log but WER/CER/similarity = N/A.

---

## 1. What is the WER/CER of the existing XTTS benchmark outputs?  [MEASURED]

Pass-2 clean runs (the only ones with retained audio):

| length | n | WER (mean / min / max) | CER (mean / min / max) |
|---|---|---|---|
| short (5 words) | 1 | 0.000 / 0.000 / 0.000 | 0.000 / 0.000 / 0.000 |
| medium (13 words) | 3 | 0.000 / 0.000 / 0.000 | 0.000 / 0.000 / 0.000 |
| long (27 words) | 3 | 0.086 / 0.037 / 0.148 | 0.031 / 0.011 / 0.071 |

Pass-2 anomaly-affected runs (retried, output retained): short_1 WER 0.600,
CER 0.391; short_3 WER 1.000, CER 0.739. Full per-run numbers in
`01_CONTENT/xtts_content_summary.md`.

## 2. Is the content preserved across lengths?  [MEASURED]

Clean outputs: short and medium are verbatim-perfect (WER 0.000, 7/7 runs).
Long outputs are correct except the single term `RTX A5000 Grafikkarte`
(garbled in 3/3 runs: `RTKS A5000` / `RTS F5000` / `RTXis auf 5000 Karte`);
all other words are correct. Conclusion: content is preserved up to 13 words
perfectly and essentially preserved at 27 words, with a consistent weakness
on a dense technical term.

## 3. Is the target voice preserved (similarity to the reference speaker)?  [MEASURED]

- Target set self-consistency (leave-one-out): mean cosine 0.955 ± 0.021,
  range 0.902–0.973 (n = 8).
- XTTS outputs vs. target centroid: short 0.60, medium 0.765–0.782,
  long 0.800–0.811. Max XTTS similarity 0.811 stays below the worst
  within-speaker leave-one-out value (0.902).

Descriptive interpretation: the generated voice is acoustically distinct
from the authentic target-speaker recordings at every length. Similarity
rises with output duration (short < medium < long), which is consistent with
CAMPPlus being trained on longer segments; cross-duration comparisons are
therefore not directly meaningful, and no threshold/identity claim is made.

## 4. Do duration anomalies correlate with content errors?  [MEASURED]

Yes, in both passes. Pass 2: the two anomaly-retry-affected short outputs
have WER 0.600 / 1.000 while all seven clean outputs have WER 0.000 (short_2)
or ≤ 0.148 (long). Pass 1: the three runs flagged as anomalous in the log
(short_2, short_3, medium_1, RTF 1.84–3.33) are exactly the runs with
> 10 s generation time, i.e. the same failure mode. The single retained
27.9 s loop artifact has WER 1.400 — no coherent content. Sample sizes are
small; the correlation is descriptive, not a fitted model.

## 5. How do these results compare with the STS / latency benchmark?  [DERIVED]

From `03_COMBINED/xtts_final_metrics.csv` (pass-1 timing from the log,
pass-2 timing from the log + on-disk durations):

- Clean runs: real-time factor ≈ 0.4 everywhere (medium 0.40, long 0.40,
  short_2 0.47) and content is essentially perfect → latency and content
  quality agree on the clean subset.
- Anomaly runs: RTF jumps above 1 (1.84–4.42) because the failed
  autoregressive loop generation takes 11–23 s of wall time; the same runs
  (pass 1) or the retry-affected siblings (pass 2) show the content errors.
  The duration anomaly and the content degradation are the same underlying
  failure, seen from the two measurements.
- Pass-1 anomalous runs were saved unconditionally (no guard); pass-2 added
  a guard + retry, so pass-2 saved outputs are cleaner but slower in the
  retried runs (short_1 11.99 s / short_3 23.13 s generation time).

## 6. Is the TTS voice "recognizably the same person" to human listeners?  [NOT SUPPORTED]

No human listener study was conducted. CAMPPlus similarity is a technical
proxy and cannot support a perceptual identity claim. The measured
similarity gap vs. the authentic target speaker (0.60–0.81 vs. within-speaker
0.90–0.97) indicates the generated voice is not identical to the reference
recordings, but "recognizability" to humans is not measured here.

## 7. Is the system ready for real-world assistant use?  [DERIVED]

Narrow technical readiness for the tested conditions: yes for clean runs —
verbatim content up to 13 words, ≤ 0.15 WER at 27 words, RTF ≈ 0.4 on the
RTX A5000. Not ready for unguarded production: the autoregressive loop
failure occurred in 3/9 pass-1 runs and 2/9 pass-2 runs (short texts, bursty),
produces ~27 s degenerate audio, and even the retried outputs retain audible
artifacts (filler / inserted phrase). Emotional control is limited: the sad
utterance shifts the speaker embedding far from neutral (0.428 vs. 0.755),
i.e. prosody degrades the voice embedding, and the shift is comparable to
the degenerate loop artifact. These are quantitative stability/robustness
limitations, not quality verdicts.

---

## Top-3 quantitative findings

1. Clean XTTS outputs preserve content: WER 0.000 for short+medium (7/7 runs),
   and ≤ 0.148 (one-word error, the term `RTX A5000 Grafikkarte`) for 27-word
   outputs.
2. The voice is acoustically distinct from the authentic target speaker at
   every length (max similarity 0.811 vs. within-speaker ≥ 0.902), and
   similarity is duration-sensitive (0.60 short → 0.81 long).
3. Duration anomalies and content errors are the same failure: the
   autoregressive loop (retained 27.9 s artifact: ~2.5 s of real speech + a
   degenerate low-energy tail, WER 1.4, similarity 0.43) inflates RTF to
   1.8–4.4 and degrades the retried outputs (WER 0.6–1.0).

## Files

- `00_REPORT/FINAL_TTS_METRICS_REPORT.md` (this file)
- `00_REPORT/scripts/content_metrics.py` — ASR + WER/CER (reproducibility)
- `00_REPORT/scripts/speaker_similarity.py` — CAMPPlus embedding + similarity
- `01_CONTENT/xtts_content_metrics.csv`, `01_CONTENT/xtts_content_summary.md`
- `02_SIMILARITY/target_reference_set.csv`, `target_set_stats.csv`,
  `xtts_speaker_similarity.csv`, `emotion_similarity.csv`
- `03_COMBINED/xtts_final_metrics.csv` — 18-row latency + content + similarity table