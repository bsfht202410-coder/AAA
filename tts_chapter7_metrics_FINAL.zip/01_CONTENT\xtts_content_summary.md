# XTTS Content Preservation — Summary (WER/CER)

Method: faster-whisper `large-v3-turbo` (cached), beam 5, temperature 0,
language de, `condition_on_previous_text=False`. Transcripts normalized
(lowercase, punctuation removed) then compared with jiwer against the
verified expected texts. WER = word error rate, CER = character error rate.

Evidence file: `01_CONTENT/xtts_content_metrics.csv` (10 rows: 9 benchmark
outputs + 1 retained loop probe).

## A. Clean runs (pass 2, no anomaly, n = 7)

| length | runs | WER | CER |
|---|---|---|---|
| short (5 words) | short_2 | 0.000 | 0.000 |
| medium (13 words) | medium_1..3 | 0.000 / 0.000 / 0.000 | 0.000 / 0.000 / 0.000 |
| long (27 words) | long_1..3 | 0.037 / 0.074 / 0.148 | 0.011 / 0.011 / 0.071 |

Clean short and medium outputs are verbatim-perfect. All long outputs are
verbatim except one word: the technical term `RTX A5000 Grafikkarte` is
garbled in every long run (`RTKS A5000`, `RTS F5000`, `RTXis auf 5000 Karte`).
Every other word of the 27-word text is correct, so the errors are
concentrated in a single acoustically-dense proper noun.

## B. Anomaly-affected runs (pass 2, retried, n = 2)

| run | status | WER | CER | transcript (as transcribed) |
|---|---|---|---|---|
| short_1 | ANOMALY_RETRY (2 retries) | 0.600 | 0.391 | `Hallo? Wie geht es dir? Ähm...` |
| short_3 | ANOMALY_RETRY (2 retries) | 1.000 | 0.739 | `Hallo? Wie geht es dir? Oh nein, nein.` |

Both retry-affected outputs preserve the requested sentence frame but carry
audible artifacts: a hesitation filler (`Ähm`) and an inserted hallucinated
phrase (`Oh nein, nein.`). The utterance is not cleanly produced even in the
saved retry result.

## C. Loop failure-type characterization

No anomalous 27 s audio from the guarded benchmark runs was ever saved (the
guard discards it). The only retained artifact of the same failure is
`data/audio/outputs/cli_interactive_20260811_231341.wav` (27.95 s, from the
interactive session that produced the same 27 s anomaly).

Evidence on that file:
- ASR (timestamped): only `[0.00–2.56 s] Hallo, Peace, Peace.` contains
  speech-like content. The remaining ~25 s produce the classic whisper
  hallucination `Untertitelung des ZDF für funk, 2017` (nothing intelligible).
- RMS energy per second: sec 0 = 0.154 (real speech), secs 1–26 = 0.018–0.047
  sustained low-energy tail — neither silence nor clean speech.
- WER 1.400, CER 1.080 against `Hallo. Dies ist ein Test.`
- CAMPPlus similarity vs. target speaker: 0.428 (no target-speaker content).

Interpretation (indicative, single sample): the failure is an
autoregressive repetition/looping failure — a short speech unit is
repeated/re-looped into a degenerate low-energy tail until the length cap.
It is a generated-audio failure, not silence and not plausible extra content.

## Numeric table (pass 2, per run)

| file | status | WER | CER | subs | dels | ins | ref words | hyp words |
|---|---|---|---|---|---|---|---|---|
| lat15_short_1.wav | ANOMALY_RETRY | 0.600 | 0.391 | 2 | 0 | 1 | 5 | 6 |
| lat15_short_2.wav | CLEAN | 0.000 | 0.000 | 0 | 0 | 0 | 5 | 5 |
| lat15_short_3.wav | ANOMALY_RETRY | 1.000 | 0.739 | 2 | 0 | 3 | 5 | 8 |
| lat15_medium_1.wav | CLEAN | 0.000 | 0.000 | 0 | 0 | 0 | 13 | 13 |
| lat15_medium_2.wav | CLEAN | 0.000 | 0.000 | 0 | 0 | 0 | 13 | 13 |
| lat15_medium_3.wav | CLEAN | 0.000 | 0.000 | 0 | 0 | 0 | 13 | 13 |
| lat15_long_1.wav | CLEAN | 0.037 | 0.011 | 1 | 0 | 0 | 27 | 27 |
| lat15_long_2.wav | CLEAN | 0.074 | 0.011 | 2 | 0 | 0 | 27 | 27 |
| lat15_long_3.wav | CLEAN | 0.148 | 0.071 | 3 | 0 | 1 | 27 | 28 |
| cli_interactive_20260811_231341.wav | RETAINED_27.9S | 1.400 | 1.080 | 5 | 0 | 2 | 5 | 7 |