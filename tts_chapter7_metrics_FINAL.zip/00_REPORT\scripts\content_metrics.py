"""Content-preservation metrics (WER/CER) on EXISTING XTTS benchmark outputs.

Read-only with respect to the TTS project:
- loads the fixed German ASR (faster-whisper large-v3-turbo, cached locally)
- transcribes the existing Hand-15 pass-2 benchmark WAVs (lat15_*.wav)
- computes WER/CER with jiwer against the exact normalized XTTS input text
- also probes the retained 27.9 s CLI generation (anomaly-loop signature)

No new speech is generated.
"""

import csv
import sys
from pathlib import Path

import jiwer
import soundfile as sf
from faster_whisper import WhisperModel

ROOT = Path(r"C:\Users\pcai\Desktop\TTStest")
OUT = Path(r"C:\Users\pcai\AppData\Local\Temp\opencode\ch7final\01_CONTENT")

ASR_MODEL = "mobiuslabsgmbh/faster-whisper-large-v3-turbo"
BEAM = 5
TEMPERATURE = 0
LANGUAGE = "de"

# Exact normalized texts passed to XTTS (normalizer left them unchanged,
# verified in the Hand-15 analysis: changed=false for all three).
TEXTS = {
    "short": "Hallo, wie geht es dir?",
    "medium": "Das Wetter in Österreich ist heute sehr schön und wir sollten spazieren gehen.",
    "long": "Dies ist ein längerer deutscher Text, um die Stabilität, die Qualität und die Geschwindigkeit der Sprachgenerierung auf der RTX A5000 Grafikkarte ausführlich zu testen und zu messen.",
}

# (category, run, wav, anomaly_status, gen_s, audio_s, rtf) - from latency_pass2.txt
BENCH = [
    ("short", 1, "lat15_short_1.wav", "ANOMALY_RETRY", 11.985, 3.25, 3.69),
    ("short", 2, "lat15_short_2.wav", "CLEAN", 0.899, 1.93, 0.47),
    ("short", 3, "lat15_short_3.wav", "ANOMALY_RETRY", 23.129, 5.24, 4.42),
    ("medium", 1, "lat15_medium_1.wav", "CLEAN", 1.954, 4.89, 0.40),
    ("medium", 2, "lat15_medium_2.wav", "CLEAN", 1.908, 4.72, 0.40),
    ("medium", 3, "lat15_medium_3.wav", "CLEAN", 2.357, 5.95, 0.40),
    ("long", 1, "lat15_long_1.wav", "CLEAN", 4.815, 11.73, 0.41),
    ("long", 2, "lat15_long_2.wav", "CLEAN", 4.085, 10.32, 0.40),
    ("long", 3, "lat15_long_3.wav", "CLEAN", 4.230, 10.37, 0.41),
]

# Retained 27.95 s CLI generation: loop-anomaly signature probe.
PROBE = ("cli_interactive_20260811_231341.wav", "Hallo. Dies ist ein Test.")


def transcribe(model, path):
    data, sr = sf.read(str(path), dtype="float32")
    segs, info = model.transcribe(
        data,
        beam_size=BEAM,
        temperature=TEMPERATURE,
        language=LANGUAGE,
        condition_on_previous_text=False,
        without_timestamps=True,
        vad_filter=False,
    )
    text = "".join(s.text for s in segs).strip()
    return text, round(float(info.language_probability), 4), sr


def metrics(ref, hyp):
    w = jiwer.process_words(ref, hyp)
    c = jiwer.process_characters(ref, hyp)
    return {
        "wer": round(w.wer, 4),
        "cer": round(c.cer, 4),
        "substitutions": w.substitutions,
        "deletions": w.deletions,
        "insertions": w.insertions,
        "hits": w.hits,
        "ref_words": len(ref.split()),
        "hyp_words": len(hyp.split()),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    print("loading ASR:", ASR_MODEL)
    model = WhisperModel(ASR_MODEL, device="cuda", compute_type="float16")

    rows = []
    for cat, run, wav, status, gen_s, audio_s, rtf in BENCH:
        path = ROOT / "outputs" / wav
        hyp, lang_p, sr = transcribe(model, path)
        ref = TEXTS[cat]
        m = metrics(ref, hyp)
        rows.append({
            "sentence_category": cat, "pass": 2, "run": run, "output_wav": wav,
            "anomaly_status": status, "expected_normalized_text": ref,
            "asr_transcript": hyp, "wer": m["wer"], "cer": m["cer"],
            "substitutions": m["substitutions"], "deletions": m["deletions"],
            "insertions": m["insertions"], "reference_word_count": m["ref_words"],
            "hypothesis_word_count": m["hyp_words"],
            "generation_time_s": gen_s, "output_duration_s": audio_s, "rtf": rtf,
            "asr_language_prob": lang_p, "wav_sr": sr,
        })
        print(f"{wav}: WER={m['wer']:.3f} CER={m['cer']:.3f}")

    probe_wav, probe_ref = PROBE
    hyp_p, lang_p, sr = transcribe(model, ROOT / "data/audio/outputs" / probe_wav)
    m = metrics(probe_ref, hyp_p)
    rows.append({
        "sentence_category": "probe_loop", "pass": "", "run": "",
        "output_wav": probe_wav, "anomaly_status": "RETAINED_27.9S_GENERATION",
        "expected_normalized_text": probe_ref, "asr_transcript": hyp_p,
        "wer": m["wer"], "cer": m["cer"], "substitutions": m["substitutions"],
        "deletions": m["deletions"], "insertions": m["insertions"],
        "reference_word_count": m["ref_words"], "hypothesis_word_count": m["hyp_words"],
        "generation_time_s": "", "output_duration_s": 27.9467, "rtf": "",
        "asr_language_prob": lang_p, "wav_sr": sr,
    })
    print(f"probe {probe_wav}: WER={m['wer']:.3f} CER={m['cer']:.3f}")

    fieldnames = list(rows[0].keys())
    with open(OUT / "xtts_content_metrics.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
    print("wrote", OUT / "xtts_content_metrics.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())