"""campplus_sim.py - COMMON speaker-similarity protocol for Chapter 7.

ONE implementation (CAMPPlus, funasr cn_common checkpoint) for every file.
Target centroid = normalized mean of the L2-normalized embeddings of the
10 authentic target clips (target_reference_set.csv). Genuine-target baseline =
leave-one-out cosine of each target clip vs the centroid of the other 9.
No thresholds, no perceptual interpretation.

Run with the seed-vc venv from tools/seed-vc/repo.
"""
import json
import os

import librosa
import numpy as np
import soundfile as sf
import torch

REPO = r"C:\AI\Beatrice\tools\seed-vc\repo"
os.chdir(REPO)
import sys
sys.path.insert(0, REPO)
from modules.campplus.DTDNN import CAMPPlus  # noqa: E402

OUT = r"C:\AI\Beatrice\output\sts_common_metrics_stage\sts_chapter7_common_metrics"
SV = r"C:\AI\Beatrice\output\seedvc_validation"
RV = r"C:\AI\Beatrice\output\rvc_validation"
MT = r"C:\AI\Beatrice\output\seedvc_validation\matched_test"
FIT = r"C:\AI\Beatrice\output\diag\final_identity_test"

CKPT = os.path.join(REPO, "checkpoints", "models--funasr--campplus", "snapshots",
                    "e4b6ede7ce16997aff4ae69fbca1f0175e2afede", "campplus_cn_common.bin")

# (label, path, source_lesson/source, criterion)
TARGETS = [
    ("prof_ref_01", os.path.join(FIT, "target_professor", "prof_ref_01.wav"), "lesson set (identity study)", "pre-curated clean ref (centroid refs, identity study)"),
    ("prof_ref_02", os.path.join(FIT, "target_professor", "prof_ref_02.wav"), "lesson set (identity study)", "pre-curated clean ref (centroid refs, identity study)"),
    ("prof_ref_03", os.path.join(FIT, "target_professor", "prof_ref_03.wav"), "lesson set (identity study)", "pre-curated clean ref (centroid refs, identity study)"),
    ("prof_ref_04", os.path.join(FIT, "target_professor", "prof_ref_04.wav"), "lesson set (identity study)", "pre-curated clean ref (centroid refs, identity study)"),
    ("prof_ref_05", os.path.join(FIT, "target_professor", "prof_ref_05.wav"), "lesson set (identity study)", "pre-curated clean ref (centroid refs, identity study)"),
    ("prof_holdout_01", os.path.join(FIT, "prof_holdout", "prof_holdout_01.wav"), "lesson set (identity study)", "pre-curated clean holdout (identity study)"),
    ("prof_holdout_02", os.path.join(FIT, "prof_holdout", "prof_holdout_02.wav"), "lesson set (identity study)", "pre-curated clean holdout (identity study)"),
    ("prof_holdout_03", os.path.join(FIT, "prof_holdout", "prof_holdout_03.wav"), "lesson set (identity study)", "pre-curated clean holdout (identity study)"),
    ("train_slice_audio1", os.path.join(r"C:\AI\Beatrice\datasets\GermanLecturer_training\GermanLecturer", "GermanLecturer_audio1.w_00137.wav"), "audio1.wav", "kept training slice (196 kept), 10.34 s, shortest lesson-1 slice >= 10 s"),
    ("train_slice_audio2", os.path.join(r"C:\AI\Beatrice\datasets\GermanLecturer_training\GermanLecturer", "GermanLecturer_audio2.w_00244.wav"), "audio2.wav", "kept training slice (196 kept), 9.86 s, shortest lesson-2 slice"),
]

# (label, source_id, system, model, path)
EVAL = [
    ("hist_source", "hist", "source", "none (author recording)", os.path.join(SV, "seedvc_hist_lecturer.wav")),
    ("hist_rvc", "hist", "RVC", "GermanLecturerRVC (e190)", os.path.join(RV, "rvc_hist_lecturer.wav")),
    ("hist_seedvc", "hist", "Seed-VC", "1.0_30_0.7 baseline", os.path.join(SV, "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav")),
    ("test01_source", "test01", "source", "none (author recording)", os.path.join(SV, "seedvc_test01_lecturer.wav")),
    ("test01_rvc", "test01", "RVC", "GermanLecturerRVC (e190)", os.path.join(RV, "rvc_test01_lecturer.wav")),
    ("test01_seedvc", "test01", "Seed-VC", "1.0_30_0.7 baseline", os.path.join(SV, "vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav")),
    ("prepared_source", "prepared", "source", "none (author recording)", os.path.join(MT, "source_mine_prepared_48k.wav")),
    ("prepared_rvc_h0", "prepared", "RVC", "RVC_Audit8 e800 harvest p0", os.path.join(RV, "rvc_harvest_p0.wav")),
    ("prepared_rvc_h2", "prepared", "RVC", "RVC_Audit8 e800 harvest p2", os.path.join(RV, "rvc_harvest_p2.wav")),
    ("prepared_rvc_r0", "prepared", "RVC", "RVC_Audit8 e800 rmvpe p0", os.path.join(RV, "rvc_rmvpe_p0.wav")),
    ("prepared_rvc_r2", "prepared", "RVC", "RVC_Audit8 e800 rmvpe p2", os.path.join(RV, "rvc_rmvpe_p2.wav")),
    ("prepared_seedvc", "prepared", "Seed-VC", "1.0_30_0.7 baseline", os.path.join(MT, "result_baseline_newrec.wav")),
    ("hist_seedvc_100st", "hist", "Seed-VC variant", "1.0_100_0.7 (100 steps)", os.path.join(SV, "variants", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav")),
    ("hist_seedvc_64t15", "hist", "Seed-VC variant", "1.0_64_1.5 (64 steps, t=1.5)", os.path.join(SV, "variants", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav")),
]

device = "cuda" if torch.cuda.is_available() else "cpu"
model = CAMPPlus(feat_dim=80, embedding_size=192)
model.load_state_dict(torch.load(CKPT, map_location="cpu"))
model.eval().to(device)


def embed(path):
    x, sr = sf.read(path, dtype="float32", always_2d=False)
    if sr != 16000:
        x = librosa.resample(x, orig_sr=sr, target_sr=16000).astype(np.float32)
    spec = librosa.stft(x, n_fft=512, hop_length=160, win_length=512, center=True)
    mag = np.abs(spec)
    mel = librosa.filters.mel(sr=16000, n_fft=512, n_mels=80, fmin=0, fmax=8000)
    m = (mel @ mag).T  # (T, 80)
    m = np.log(np.clip(m, 1e-5, None))
    t = torch.from_numpy(m[None]).float().to(device)
    with torch.no_grad():
        e = model(t)[0].cpu().numpy()
    e = e / (np.linalg.norm(e) + 1e-9)
    return e


def cos(a, b):
    return float(np.dot(a, b))


def main():
    import csv
    tgt_files = [(label, path) for label, path, _l, _c in TARGETS]
    tgt_emb = {label: embed(path) for label, path in tgt_files}

    rows = []
    for label, path, lesson, crit in TARGETS:
        d = sf.info(path)
        rows.append({
            "clip_id": label, "wav": os.path.basename(path),
            "source_lesson": lesson, "duration_s": round(d.frames / d.samplerate, 3),
            "sha256": hashlib256(path), "selection_criterion": crit,
            "excluded_refs_note": "seedvc_ref_lecturer.wav / target_gt_lecturer_mono.wav / audio4_chunk_080.wav (XTTS golden, not found in project) NOT used",
        })
    with open(os.path.join(OUT, "03_SIMILARITY", "target_reference_set.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    # centroid + leave-one-out
    names = [r["clip_id"] for r in rows]
    cent = sum(tgt_emb[n] for n in names)
    cent = cent / np.linalg.norm(cent)
    loo = {n: cos(tgt_emb[n], (sum(tgt_emb[m] for m in names if m != n) / np.linalg.norm(
        sum(tgt_emb[m] for m in names if m != n)))) for n in names}
    emb_out = {"target_embeddings": {n: tgt_emb[n].tolist() for n in names},
               "centroid": cent.tolist(), "loo_cosine": loo,
               "model": "CAMPPlus cn_common 192-d", "ckpt": CKPT,
               "n_targets": len(names), "notes": "targets: 5 identity-study refs + 3 holdouts + 2 kept training slices (lessons 1-2)"}

    sim_rows = [["source_id", "system", "model", "output_wav", "campplus_similarity_to_target_centroid",
                 "campplus_similarity_to_source", "duration_s", "note"]]
    COPIES = {
        "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav":
            "BYTE-IDENTICAL COPY OF SOURCE (sha256 match) - not genuine Seed-VC output",
        "vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav":
            "BYTE-IDENTICAL COPY OF SOURCE (sha256 match) - not genuine Seed-VC output",
    }
    src_emb = {}
    for label, sid, system, mdl, path in EVAL:
        e = embed(path)
        if sid not in src_emb and system == "source":
            src_emb[sid] = e
        d = sf.info(path)
        sim_rows.append([sid, system, mdl, os.path.basename(path),
                         round(cos(e, cent), 4),
                         round(cos(e, src_emb[sid]), 4) if sid in src_emb else "",
                         round(d.frames / d.samplerate, 2), COPIES.get(os.path.basename(path), "")])
        emb_out.setdefault("eval_embeddings", {})[os.path.basename(path)] = e.tolist()
    with open(os.path.join(OUT, "03_SIMILARITY", "common_speaker_similarity.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(sim_rows[0])
        w.writerows(sim_rows[1:])
    with open(os.path.join(OUT, "03_SIMILARITY", "embeddings.json"), "w", encoding="utf-8") as f:
        json.dump(emb_out, f)
    print("target LOO mean %.4f min %.4f max %.4f" % (
        np.mean(list(loo.values())), min(loo.values()), max(loo.values())))
    print("wrote target_reference_set.csv + common_speaker_similarity.csv + embeddings.json")


def hashlib256(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


if __name__ == "__main__":
    main()