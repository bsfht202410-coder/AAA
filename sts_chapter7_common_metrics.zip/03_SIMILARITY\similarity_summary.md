# Common speaker-similarity summary (CAMPPlus, one protocol)

**Implementation:** CAMPPlus (funasr `campplus_cn_common.bin`, 192-d embeddings) — identical
code path for every file (see `04_REPRODUCIBILITY/scripts/campplus_sim.py`). Input: 16 kHz,
80-mel, log-compressed spectra (same as the previous package's CAMPPlus runs).

**Target reference set (10 authentic clips, `target_reference_set.csv`):**
5 identity-study reference clips (`prof_ref_01..05`), 3 identity-study holdouts
(`prof_holdout_01..03`), 2 kept training slices (lessons 1 and 2). All are genuine lecturer
speech. Excluded by design: `seedvc_ref_lecturer.wav`, `target_gt_lecturer_mono.wav`, and
`audio4_chunk_080.wav` (XTTS golden reference — **not found in the project**, so nothing to
exclude there; no lesson-4 audio was used in the set).

**Centroid:** normalized mean of the 10 L2-normalized embeddings, re-normalized.

## Genuine-target baseline (leave-one-out)
| metric | value |
|---|---|
| LOO mean | **0.9455** |
| LOO min | 0.9126 |
| LOO max | 0.9741 |

This is the expected range for authentic target-speaker clips vs the centroid. Real
target speech scores ~0.91–0.97; the author's own voice scores 0.87–0.92 against the
target centroid (source-to-target baseline below).

## Source-to-target baseline (author's own voice vs target centroid)
| source | similarity |
|---|---|
| hist (20.06 s) | 0.8748 |
| test01 (11.99 s) | 0.9188 |
| prepared (21.20 s) | 0.8659 |

The author's voice is clearly below the genuine-target band (except test01 at 0.919,
which overlaps the low end of the genuine range — the two voices are relatively close in
this embedding space; this is a known property, cf. `07_HUMAN_EVALUATION` WAVLM weakness
in the previous package).

## Converted outputs vs the SAME target centroid
| source | system | model | sim→centroid | sim→source | note |
|---|---|---|---|---|---|
| hist | RVC | GermanLecturerRVC (e190) | 0.8736 | 0.7142 | — |
| hist | Seed-VC | 1.0_30_0.7 "baseline" | 0.8748 | 1.0 | **copy of source (sha256 match) — not genuine** |
| hist | Seed-VC | 1.0_100_0.7 | 0.8911 | 0.9914 | genuine variant |
| hist | Seed-VC | 1.0_64_1.5 | 0.8723 | 0.9886 | genuine variant |
| test01 | RVC | GermanLecturerRVC (e190) | 0.7750 | 0.6706 | — |
| test01 | Seed-VC | 1.0_30_0.7 "baseline" | 0.9188 | 1.0 | **copy of source (sha256 match) — not genuine** |
| prepared | RVC | RVC_Audit8 harvest p0 | 0.9306 | 0.9203 | — |
| prepared | RVC | RVC_Audit8 harvest p2 | 0.9593 | 0.8839 | — |
| prepared | RVC | RVC_Audit8 rmvpe p0 | 0.9198 | 0.9295 | — |
| prepared | RVC | RVC_Audit8 rmvpe p2 | 0.9565 | 0.8805 | — |
| prepared | Seed-VC | 1.0_30_0.7 baseline | 0.9153 | 0.7943 | genuine |

## Reading (objective, no threshold, no perception claims)
- **RVC_Audit8 (e800):** all four outputs (0.9198–0.9593) are inside or at the
  genuine-target LOO band (0.91–0.97) and well above their source baseline (0.8659).
  pitch+2 (0.9565–0.9593) > pitch 0 (0.9198–0.9306).
- **GermanLecturerRVC (e190):** hist output 0.8736 ≈ its source 0.8748 (no measurable
  movement toward the target); test01 output 0.7750 is *below* its source 0.9188 (moves
  away from both). The two-source average is below the source baseline.
- **Seed-VC:** genuine outputs score 0.8723–0.9153 — at or slightly above their sources
  but below the genuine-target band and below RVC_Audit8 on the prepared clip. The
  hist/test01 "baseline" files are not genuine outputs (copies of the input).
- Do NOT interpret these numbers as "who a person would be recognized as"; CAMPPlus is an
  objective embedding-similarity measure only, and the author/target pair is close in this
  space (see the source baseline and the previous package's WAVLM-vs-ECAPA discussion).