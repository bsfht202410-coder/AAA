"""asr_transcribe.py - fixed-protocol ASR transcription for the Chapter 7 common metrics.

ONE fixed ASR model for the whole evaluation: faster-whisper-large-v3-turbo (cached
Systran/mobiuslabsgmbh HF model), language=de. Fixed decoding settings for every file:
beam_size=5, temperature=0.0, vad_filter=False, condition_on_previous_text=True,
word_timestamps=True. NO per-system tuning.

Additionally runs faster-whisper-medium with identical settings on the three SOURCE
recordings only, as a cross-check aid for the manual ground-truth step.

Run:  python asr_transcribe.py   (audiosr venv, GPU)
"""
import json
import os

from faster_whisper import WhisperModel

OUT = r"C:\AI\Beatrice\output\sts_common_metrics_stage\sts_chapter7_common_metrics"
SV = r"C:\AI\Beatrice\output\seedvc_validation"
RV = r"C:\AI\Beatrice\output\rvc_validation"
MT = r"C:\AI\Beatrice\output\seedvc_validation\matched_test"

SETTINGS = dict(
    model="faster-whisper-large-v3-turbo",
    device="cuda", compute_type="float16",
    language="de", beam_size=5, temperature=0.0,
    vad_filter=False, condition_on_previous_text=True, word_timestamps=True,
)

# (file_id, system, model, path)
MANIFEST = [
    ("hist",       "source",            "none (author recording)",    os.path.join(SV, "seedvc_hist_lecturer.wav")),
    ("hist",       "RVC",               "GermanLecturerRVC (e190)",   os.path.join(RV, "rvc_hist_lecturer.wav")),
    ("hist",       "Seed-VC",           "1.0_30_0.7 baseline",        os.path.join(SV, "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav")),
    ("test01",     "source",            "none (author recording)",    os.path.join(SV, "seedvc_test01_lecturer.wav")),
    ("test01",     "RVC",               "GermanLecturerRVC (e190)",   os.path.join(RV, "rvc_test01_lecturer.wav")),
    ("test01",     "Seed-VC",           "1.0_30_0.7 baseline",        os.path.join(SV, "vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav")),
    ("prepared",   "source",            "none (author recording)",    os.path.join(MT, "source_mine_prepared_48k.wav")),
    ("prepared",   "RVC",               "RVC_Audit8 e800 harvest p0", os.path.join(RV, "rvc_harvest_p0.wav")),
    ("prepared",   "RVC",               "RVC_Audit8 e800 harvest p2", os.path.join(RV, "rvc_harvest_p2.wav")),
    ("prepared",   "RVC",               "RVC_Audit8 e800 rmvpe p0",   os.path.join(RV, "rvc_rmvpe_p0.wav")),
    ("prepared",   "RVC",               "RVC_Audit8 e800 rmvpe p2",   os.path.join(RV, "rvc_rmvpe_p2.wav")),
    ("prepared",   "Seed-VC",           "1.0_30_0.7 baseline",        os.path.join(MT, "result_baseline_newrec.wav")),
    # small well-identified variant subset (Section 5 check) - hist source
    ("hist",       "Seed-VC variant",   "1.0_100_0.7 (100 steps)",    os.path.join(SV, "variants", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav")),
    ("hist",       "Seed-VC variant",   "1.0_64_1.5 (64 steps, t=1.5)", os.path.join(SV, "variants", "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav")),
]

SOURCES = [os.path.join(SV, "seedvc_hist_lecturer.wav"),
           os.path.join(SV, "seedvc_test01_lecturer.wav"),
           os.path.join(MT, "source_mine_prepared_48k.wav")]


def transcribe(model, path):
    kw = dict(SETTINGS)
    kw.pop("model"); kw.pop("device"); kw.pop("compute_type")
    segs, info = model.transcribe(path, **kw)
    words, text = [], ""
    for s in segs:
        text += s.text + " "
        for w in (s.words or []):
            words.append({"word": w.word, "start": round(w.start, 3), "end": round(w.end, 3)})
    return {"text": text.strip(), "words": words,
            "language": info.language, "duration_s": round(info.duration, 3)}


def main():
    out = {"settings": SETTINGS, "files": {}}
    model = WhisperModel("large-v3-turbo", device="cuda", compute_type="float16")
    for fid, system, mdl, path in MANIFEST:
        r = transcribe(model, path)
        out["files"][os.path.basename(path)] = {
            "source_id": fid, "system": system, "model": mdl, "path": path, **r,
        }
        print(f"[turbo] {os.path.basename(path):65s} {system:12s} {len(r['words']):3d} words")
    with open(os.path.join(OUT, "02_CONTENT", "transcripts_all.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, ensure_ascii=False)

    aid = {"settings": dict(SETTINGS, model="faster-whisper-medium"), "files": {}}
    m2 = WhisperModel("medium", device="cuda", compute_type="float16")
    for path in SOURCES:
        r = transcribe(m2, path)
        aid["files"][os.path.basename(path)] = {**r}
        print(f"[medium] {os.path.basename(path):65s} {len(r['words']):3d} words")
    with open(os.path.join(OUT, "01_TRANSCRIPTS", "asr_crosscheck_medium.json"), "w", encoding="utf-8") as f:
        json.dump(aid, f, indent=1, ensure_ascii=False)
    print("DONE")


if __name__ == "__main__":
    main()