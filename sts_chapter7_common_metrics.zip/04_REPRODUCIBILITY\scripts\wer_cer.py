"""wer_cer.py - WER/CER computation for the Chapter 7 common content evaluation.

Standard Levenshtein alignment:
  WER = (sub+ins+del) / reference_words   (word tokens, whitespace-split)
  CER = (sub+ins+del) / reference_chars   (characters WITHOUT spaces)
Pure-Python implementation (no external metric library). Reads the ground truth from
01_TRANSCRIPTS/source_ground_truth.csv (normalized column) and the fixed-protocol ASR
transcripts from 02_CONTENT/transcripts_all.json. Writes 02_CONTENT/content_metrics.csv
and 02_CONTENT/content_analysis.md (with the ACTUAL affected words per file).
"""
import csv
import json
import os
import unicodedata
import re

OUT = r"C:\AI\Beatrice\output\sts_common_metrics_stage\sts_chapter7_common_metrics"

FILLERS = {"aeh", "aehm", "ah", "mh", "uh", "hm", "mmh"}


def normalize(text):
    t = unicodedata.normalize("NFKC", text)
    t = t.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    t = t.lower()
    t = re.sub(r"[^a-z0-9 ]", "", t)
    toks = [w for w in t.split() if w]
    toks = [w for w in toks if w not in FILLERS]
    return " ".join(toks)


def lev(a, b):
    """Levenshtein distance + alignment ops. Returns (dist, ops) where
    ops = list of (op, i_ref, i_hyp); op in m/s/d/i."""
    prev = list(range(len(b) + 1))
    prev_ops = [[("i", -1, k) for k in range(j)] for j in range(len(b) + 1)]
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        cur_ops = [prev_ops[0] + [("d", i - 1, -1)]] + [None] * len(b)
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            diag = prev[j - 1] + cost
            up = prev[j] + 1
            left = cur[j - 1] + 1
            if diag <= up and diag <= left:
                cur[j], cur_ops[j] = diag, prev_ops[j - 1] + [("m" if cost == 0 else "s", i - 1, j - 1)]
            elif up <= left:
                cur[j], cur_ops[j] = up, prev_ops[j] + [("d", i - 1, -1)]
            else:
                cur[j], cur_ops[j] = left, cur_ops[j - 1] + [("i", -1, j - 1)]
        prev, prev_ops = cur, cur_ops
    return prev[len(b)], prev_ops[len(b)]


def main():
    gt = {}
    with open(os.path.join(OUT, "01_TRANSCRIPTS", "source_ground_truth.csv"), encoding="utf-8") as f:
        for r in csv.DictReader(f):
            gt[r["source_id"]] = normalize(r["normalized_transcript"])

    tr = json.load(open(os.path.join(OUT, "02_CONTENT", "transcripts_all.json"), encoding="utf-8"))["files"]

    rows, md_lines = [], []
    md_lines.append("# Content analysis (WER/CER) — word-level findings")
    md_lines.append("")
    md_lines.append("ASR: faster-whisper-large-v3-turbo, de, beam 5, temp 0 (fixed for ALL files). "
                    "Reference = normalized ground-truth transcript of the source recording. "
                    "WER/CER use standard Levenshtein (see wer_cer.py).")
    md_lines.append("")

    NOTES = {
        "vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav":
            "FILE IS BYTE-IDENTICAL COPY OF THE SOURCE (SHA-256 match, max_abs_diff 0.0) - "
            "not a genuine Seed-VC conversion; metrics are trivially 0",
        "vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav":
            "FILE IS BYTE-IDENTICAL COPY OF THE SOURCE (SHA-256 match, max_abs_diff 0.0) - "
            "not a genuine Seed-VC conversion; metrics are trivially 0",
    }

    for fn, v in sorted(tr.items(), key=lambda kv: (kv[1]["source_id"], kv[1]["system"])):
        ref = gt[v["source_id"]]
        hyp = normalize(v["text"])
        rw, hw = ref.split(), hyp.split()
        dist, ops = lev(rw, hw)
        wer = dist / max(1, len(rw))
        dist_c, _ = lev(ref.replace(" ", ""), hyp.replace(" ", ""))
        cer = dist_c / max(1, len(ref.replace(" ", "")))
        subs = [o for o in ops if o[0] == "s"]
        dels = [o for o in ops if o[0] == "d"]
        inss = [o for o in ops if o[0] == "i"]
        detail = []
        for op, ri, hi in ops:
            if op == "s":
                detail.append(f"SUB {rw[ri]} -> {hw[hi]}")
            elif op == "d":
                detail.append(f"DEL {rw[ri]}")
            elif op == "i":
                detail.append(f"INS {hw[hi]}")
        rows.append({
            "source_id": v["source_id"], "system": v["system"], "model": v["model"],
            "output_wav": fn, "ASR_transcript": v["text"],
            "WER": round(wer, 4), "CER": round(cer, 4),
            "substitutions": len(subs), "deletions": len(dels), "insertions": len(inss),
            "reference_word_count": len(rw), "note": NOTES.get(fn, ""),
        })
        md_lines.append(f"## {fn}  ({v['system']} / {v['model']})")
        if NOTES.get(fn):
            md_lines.append(f"- **NOTE: {NOTES[fn]}**")
        md_lines.append(f"- WER {wer:.3f}  CER {cer:.3f}  S{len(subs)} D{len(dels)} I{len(inss)}  "
                        f"ref_words={len(rw)}")
        md_lines.append(f"- reference : {ref}")
        md_lines.append(f"- hypothesis: {hyp}")
        if detail:
            md_lines.append(f"- word-level: {'; '.join(detail)}")
        else:
            md_lines.append("- word-level: no differences")
        md_lines.append("")

    with open(os.path.join(OUT, "02_CONTENT", "content_metrics.csv"), "w",
              newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    with open(os.path.join(OUT, "02_CONTENT", "content_analysis.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md_lines))
    print("wrote content_metrics.csv (%d rows) + content_analysis.md" % len(rows))


if __name__ == "__main__":
    main()