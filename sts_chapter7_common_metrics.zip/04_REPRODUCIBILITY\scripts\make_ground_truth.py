"""make_ground_truth.py - builds 01_TRANSCRIPTS/source_ground_truth.csv.

Verbatim transcripts of the three source recordings are taken from the fixed-protocol
ASR (faster-whisper-large-v3-turbo, de) and cross-checked against faster-whisper-medium
(asr_crosscheck_medium.json). NOTE: an automatic transcript is NOT final ground truth;
the author must listen to the three WAVs and correct the verbatim column if needed
(status flag in the CSV). No silent correction is applied here.

Normalization rules (documented, applied identically in wer_cer.py):
 1. NFKC unicode normalization (umlauts retained)
 2. lower-case
 3. remove ALL punctuation (including hyphens, quotes, commas) -> tokens joined
 4. split on whitespace, drop empty tokens
 5. digits kept as written (no expansion)
 6. hesitations/fillers (aeh/aehm/uh/mh/... after umlaut-replacement) dropped
"""
import csv
import json
import os
import re
import unicodedata

OUT = r"C:\AI\Beatrice\output\sts_common_metrics_stage\sts_chapter7_common_metrics"
TURBO = json.load(open(os.path.join(OUT, "02_CONTENT", "transcripts_all.json"), encoding="utf-8"))["files"]
MEDIUM = json.load(open(os.path.join(OUT, "01_TRANSCRIPTS", "asr_crosscheck_medium.json"), encoding="utf-8"))["files"]

SOURCES = [
    ("hist", "seedvc_hist_lecturer.wav"),
    ("test01", "seedvc_test01_lecturer.wav"),
    ("prepared", "source_mine_prepared_48k.wav"),
]

UMLAUT = {"ae": "a", "oe": "o", "ue": "u", "ss": "ss"}
FILLERS = {"aeh", "aehm", "ah", "mh", "uh", "hm", "mmh"}


def normalize(text):
    t = unicodedata.normalize("NFKC", text)
    t = t.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    t = t.lower()
    t = re.sub(r"[^a-z0-9 ]", "", t)          # remove punctuation
    toks = [w for w in t.split() if w]
    toks = [w for w in toks if w not in FILLERS]
    return " ".join(toks)


def norm_words(text):
    return normalize(text).split()


rows = []
for fid, fn in SOURCES:
    tb = TURBO[fn]["text"]
    md = MEDIUM[fn]["text"]
    tb_w, md_w = norm_words(tb), norm_words(md)
    agree = round(1.0 - (2 * sum(1 for a, b in zip(tb_w, md_w) if a != b) / max(1, len(tb_w) + len(md_w))), 3)
    dur = TURBO[fn]["duration_s"]
    rows.append({
        "source_id": fid,
        "source_wav": fn,
        "verbatim_transcript": tb,
        "normalized_transcript": normalize(tb),
        "duration_s": round(dur, 2),
        "notes": (f"ASR-derived (large-v3-turbo, de; word-agreement with medium cross-check "
                  f"{agree}). MANUAL LISTENING VERIFICATION REQUIRED by the author before use "
                  f"as final ground truth. Normalization per documented rules."),
    })

with open(os.path.join(OUT, "01_TRANSCRIPTS", "source_ground_truth.csv"), "w",
          newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
for r in rows:
    print(r["source_id"], "|", r["normalized_transcript"][:90])
print("wrote 01_TRANSCRIPTS/source_ground_truth.csv")