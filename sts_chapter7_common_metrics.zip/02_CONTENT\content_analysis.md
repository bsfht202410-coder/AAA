# Content analysis (WER/CER) — word-level findings

ASR: faster-whisper-large-v3-turbo, de, beam 5, temp 0 (fixed for ALL files). Reference = normalized ground-truth transcript of the source recording. WER/CER use standard Levenshtein (see wer_cer.py).

## rvc_hist_lecturer.wav  (RVC / GermanLecturerRVC (e190))
- WER 0.097  CER 0.025  S3 D0 I0  ref_words=31
- reference : wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie blah und blah gegeben
- hypothesis: wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns drachen wie bla und bla gegeben
- word-level: SUB sachen -> drachen; SUB blah -> bla; SUB blah -> bla

## vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav  (Seed-VC / 1.0_30_0.7 baseline)
- **NOTE: FILE IS BYTE-IDENTICAL COPY OF THE SOURCE (SHA-256 match, max_abs_diff 0.0) - not a genuine Seed-VC conversion; metrics are trivially 0**
- WER 0.000  CER 0.000  S0 D0 I0  ref_words=31
- reference : wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie blah und blah gegeben
- hypothesis: wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie blah und blah gegeben
- word-level: no differences

## vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_100_0.7.wav  (Seed-VC variant / 1.0_100_0.7 (100 steps))
- WER 0.097  CER 0.025  S3 D0 I0  ref_words=31
- reference : wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie blah und blah gegeben
- hypothesis: wir werden das jetzt speichern und fuer speichern verwenden wir das spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie bla und bla gegeben
- word-level: SUB die -> das; SUB blah -> bla; SUB blah -> bla

## vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_64_1.5.wav  (Seed-VC variant / 1.0_64_1.5 (64 steps, t=1.5))
- WER 0.065  CER 0.013  S2 D0 I0  ref_words=31
- reference : wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie blah und blah gegeben
- hypothesis: wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie bla und bla gegeben
- word-level: SUB blah -> bla; SUB blah -> bla

## seedvc_hist_lecturer.wav  (source / none (author recording))
- WER 0.000  CER 0.000  S0 D0 I0  ref_words=31
- reference : wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie blah und blah gegeben
- hypothesis: wir werden das jetzt speichern und fuer speichern verwenden wir die spezifische technik von euler euler wurde 1972 dieses wissen uebertragen und er hat uns sachen wie blah und blah gegeben
- word-level: no differences

## rvc_harvest_p0.wav  (RVC / RVC_Audit8 e800 harvest p0)
- WER 0.091  CER 0.038  S3 D0 I0  ref_words=33
- reference : auf welchen gesichtspunkten urspruenglich google seine seiten oder die seiten geraet hat also der google page rank algorithmus der dient dem dazu um seiten zu reihen und ein bisschen fast schon uebertrieben kitschig
- hypothesis: auf welchen gesichtspunkten urspruenglich google seine seiten oder diese seiten gereiht hat also der google page rank algorithmus der dient dem dazu um seiten zu treiben und ein bisschen fast schon uebertrieben kitschig
- word-level: SUB die -> diese; SUB geraet -> gereiht; SUB reihen -> treiben

## rvc_harvest_p2.wav  (RVC / RVC_Audit8 e800 harvest p2)
- WER 0.091  CER 0.044  S3 D0 I0  ref_words=33
- reference : auf welchen gesichtspunkten urspruenglich google seine seiten oder die seiten geraet hat also der google page rank algorithmus der dient dem dazu um seiten zu reihen und ein bisschen fast schon uebertrieben kitschig
- hypothesis: auf welchen gesichtspunkten urspruenglich google seine seiten oder diese seiten gereiht hat also der google page rank algorithmus der dient dem dazu um seiten zu primen und ein bisschen fast schon uebertrieben kitschig
- word-level: SUB die -> diese; SUB geraet -> gereiht; SUB reihen -> primen

## rvc_rmvpe_p0.wav  (RVC / RVC_Audit8 e800 rmvpe p0)
- WER 0.091  CER 0.033  S3 D0 I0  ref_words=33
- reference : auf welchen gesichtspunkten urspruenglich google seine seiten oder die seiten geraet hat also der google page rank algorithmus der dient dem dazu um seiten zu reihen und ein bisschen fast schon uebertrieben kitschig
- hypothesis: auf welchen gesichtspunkten urspruenglich google seine seiten oder diese seiten gereiht hat also der google page rank algorithmus der dient dem dazu um seiten zu reimen und ein bisschen fast schon uebertrieben kitschig
- word-level: SUB die -> diese; SUB geraet -> gereiht; SUB reihen -> reimen

## rvc_rmvpe_p2.wav  (RVC / RVC_Audit8 e800 rmvpe p2)
- WER 0.091  CER 0.033  S3 D0 I0  ref_words=33
- reference : auf welchen gesichtspunkten urspruenglich google seine seiten oder die seiten geraet hat also der google page rank algorithmus der dient dem dazu um seiten zu reihen und ein bisschen fast schon uebertrieben kitschig
- hypothesis: auf welchen gesichtspunkten urspruenglich google seine seiten oder diese seiten gereiht hat also der google page rank algorithmus der dient dem dazu um seiten zu reimen und ein bisschen fast schon uebertrieben kitschig
- word-level: SUB die -> diese; SUB geraet -> gereiht; SUB reihen -> reimen

## result_baseline_newrec.wav  (Seed-VC / 1.0_30_0.7 baseline)
- WER 0.788  CER 0.552  S18 D4 I4  ref_words=33
- reference : auf welchen gesichtspunkten urspruenglich google seine seiten oder die seiten geraet hat also der google page rank algorithmus der dient dem dazu um seiten zu reihen und ein bisschen fast schon uebertrieben kitschig
- hypothesis: ausbringungsgungle seine seiten oder die seiten gereiht hat also der googlepageship halt der dient so all ging so um seiten zu uns zu zeigen in horeingguide wie heisst von mir sollte eine exakt
- word-level: DEL auf; DEL welchen; DEL gesichtspunkten; DEL urspruenglich; SUB google -> ausbringungsgungle; SUB geraet -> gereiht; SUB google -> googlepageship; SUB page -> halt; SUB rank -> der; SUB algorithmus -> dient; SUB der -> so; SUB dient -> all; SUB dem -> ging; SUB dazu -> so; INS zu; INS uns; INS zeigen; INS in; SUB reihen -> horeingguide; SUB und -> wie; SUB ein -> heisst; SUB bisschen -> von; SUB fast -> mir; SUB schon -> sollte; SUB uebertrieben -> eine; SUB kitschig -> exakt

## source_mine_prepared_48k.wav  (source / none (author recording))
- WER 0.000  CER 0.000  S0 D0 I0  ref_words=33
- reference : auf welchen gesichtspunkten urspruenglich google seine seiten oder die seiten geraet hat also der google page rank algorithmus der dient dem dazu um seiten zu reihen und ein bisschen fast schon uebertrieben kitschig
- hypothesis: auf welchen gesichtspunkten urspruenglich google seine seiten oder die seiten geraet hat also der google page rank algorithmus der dient dem dazu um seiten zu reihen und ein bisschen fast schon uebertrieben kitschig
- word-level: no differences

## rvc_test01_lecturer.wav  (RVC / GermanLecturerRVC (e190))
- WER 0.167  CER 0.045  S2 D0 I2  ref_words=24
- reference : fahrradfahrer sollten auf der strasse verboten sein nur autos sollten auf der strasse fahren duerfen weil autos sind halt besser geeignet fuer die strassen
- hypothesis: fahrradfahrer sollten auf der strasse verboten sein nur autos sollten auf der strasse fahren die auf dem well autos sind halt besser geeignet fuer die strassen
- word-level: INS die; INS auf; SUB duerfen -> dem; SUB weil -> well

## vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav  (Seed-VC / 1.0_30_0.7 baseline)
- **NOTE: FILE IS BYTE-IDENTICAL COPY OF THE SOURCE (SHA-256 match, max_abs_diff 0.0) - not a genuine Seed-VC conversion; metrics are trivially 0**
- WER 0.000  CER 0.000  S0 D0 I0  ref_words=24
- reference : fahrradfahrer sollten auf der strasse verboten sein nur autos sollten auf der strasse fahren duerfen weil autos sind halt besser geeignet fuer die strassen
- hypothesis: fahrradfahrer sollten auf der strasse verboten sein nur autos sollten auf der strasse fahren duerfen weil autos sind halt besser geeignet fuer die strassen
- word-level: no differences

## seedvc_test01_lecturer.wav  (source / none (author recording))
- WER 0.000  CER 0.000  S0 D0 I0  ref_words=24
- reference : fahrradfahrer sollten auf der strasse verboten sein nur autos sollten auf der strasse fahren duerfen weil autos sind halt besser geeignet fuer die strassen
- hypothesis: fahrradfahrer sollten auf der strasse verboten sein nur autos sollten auf der strasse fahren duerfen weil autos sind halt besser geeignet fuer die strassen
- word-level: no differences
