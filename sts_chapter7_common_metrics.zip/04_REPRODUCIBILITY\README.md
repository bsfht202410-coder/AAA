# Reproducibility — Chapter 7 common metrics

## How to reproduce every number in this package

```
# 1. ASR (fixed protocol) - audiosr venv, GPU
python scripts/asr_transcribe.py
#    -> 02_CONTENT/transcripts_all.json  (large-v3-turbo, every evaluated file)
#    -> 01_TRANSCRIPTS/asr_crosscheck_medium.json  (medium, 3 sources only)

# 2. Ground-truth table (verbatim + normalized + notes)
python scripts/make_ground_truth.py
#    -> 01_TRANSCRIPTS/source_ground_truth.csv

# 3. WER/CER
python scripts/wer_cer.py
#    -> 02_CONTENT/content_metrics.csv
#    -> 02_CONTENT/content_analysis.md

# 4. CAMPPlus common protocol - seed-vc venv (run from tools/seed-vc/repo)
python scripts/campplus_sim.py
#    -> 03_SIMILARITY/target_reference_set.csv
#    -> 03_SIMILARITY/common_speaker_similarity.csv
#    -> 03_SIMILARITY/embeddings.json
```

All scripts read existing WAVs only. **No inference/training/generation is performed.**

## Fixed ASR protocol (identical for every file)
- Model: faster-whisper `large-v3-turbo` (cached HF model), compute_type float16, CUDA
- language="de", beam_size=5, temperature=0.0, vad_filter=False,
  condition_on_previous_text=True, word_timestamps=True
- No per-system tuning. Cross-check aid: faster-whisper `medium` with the same settings,
  applied to the three sources only.

## Normalization rules (verbatim -> normalized, used for WER/CER)
1. NFKC unicode normalization (umlauts retained)
2. lowercase
3. remove ALL punctuation (commas, periods, quotes, hyphens, …) — tokens are whitespace-split
4. digits kept as written ("1972" stays "1972"); no expansion
5. hesitation/filler tokens (aeh/aehm/ah/mh/uh/hm/mmh, after umlaut→ae/oe/ue/ss mapping) dropped
6. No other edits: the normalized transcript is a deterministic transformation of the
   verbatim transcript; anything the ASR heard is preserved.

## Environment
- audiosr venv (ASR/WER): Python 3.11.9, faster-whisper 1.2.1, ctranslate2 4.8.1,
  torch 2.6.0+cu124, librosa 0.9.2, numpy 1.26.4, soundfile 0.14.0 (see
  `environment_versions.txt`)
- seed-vc venv (CAMPPlus): Python 3.11.9, torch 2.6.0+cu124, librosa 0.10.2,
  soundfile 0.12.1 (see `environment_versions.txt`)
- GPU: NVIDIA RTX A5000 Laptop
- CAMPPlus checkpoint: `modules.campplus.DTDNN.CAMPPlus` (feat_dim 80, embedding_size 192),
  `campplus_cn_common.bin` snapshot `e4b6ede7ce16997aff4ae69fbca1f0175e2afede`

## Critical caveat (manual step)
`source_ground_truth.csv` is **ASR-derived** (large-v3-turbo, cross-checked with medium).
The author must listen to the WAVs in `01_TRANSCRIPTS/source_audio/` and confirm or correct
the `verbatim_transcript` column before it is used as final ground truth in the thesis.

## Key data-integrity finding
`vc_v2_seedvc_in_hist_seedvc_ref_lecturer_1.0_30_0.7.wav` and
`vc_v2_seedvc_in_test01_seedvc_ref_lecturer_1.0_30_0.7.wav` are **byte-identical to the
source recordings** (SHA-256 match, max abs diff 0.0). They are flagged in
`02_CONTENT/content_metrics.csv` and `03_SIMILARITY/common_speaker_similarity.csv` and must
NOT be cited as Seed-VC conversion results.