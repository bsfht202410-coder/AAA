# Final XTTS Scenario Configuration (locked for this demo)

This is the exact, unchanged FINAL XTTS configuration used in the previous
Chapter 7 evidence packages and in this scenario demo. Nothing was retuned
for Scenario 1 or Scenario 2, and nothing was changed after generation.

## 1. Model

| Item | Value |
|---|---|
| Model | XTTS-v2 (Coqui), package ID `tts_models/multilingual/multi-dataset/xtts_v2` |
| Python package | TTS 0.22.0 |
| Torch | 2.5.1+cu121 |
| Language code | `de` (German; Austrian German treated as `de` per project config) |
| Sample rate | 24000 Hz, 16-bit PCM WAV (after polish) |

## 2. Speaker source (locked golden embedding)

| Item | Value |
|---|---|
| Golden reference WAV | `models/xtts/golden_reference.wav` |
| Cached conditioning | `models/xtts/speaker_embedding_golden.pth` |
| Source clip | `audio4_chunk_080.wav` (from `data/audio/reference/`, 22.81 s; selected as golden in the established voice-selection pipeline) |
| `gpt_cond_latent` | shape (1, 32, 1024) |
| `speaker_embedding` | shape (1, 512, 1) |
| Usage | cached latents passed directly to `XTTS.inference()`; no reference WAV scanned per generation, no new reference clip selected for this demo |

## 3. Inference parameters (exact)

Fixed backend defaults (`tts/backends/xtts.py`, `DEFAULT_GEN_PARAMS`):

| Parameter | Value |
|---|---|
| temperature | 0.75 |
| top_k | 62 |
| top_p | 0.86 |
| repetition_penalty | 1.09 |
| length_penalty | 1.05 |
| enable_text_splitting | True |
| speed / pitch / volume | 1.0 / 0 semitones / 1.0 (neutral emotion = locked voice, no audio changes) |

Emotion preset: `neutral` (default). No emotional reference clip, no
emotion parameter preset, no post-hoc audio modification.

## 4. Text normalization (unchanged stage)

Normalizer: `tts/text_norm_de.py` → `normalize_german()` (abbreviations,
numbers/years, currency, percent, punctuation pacing). Applied once inside
the established engine path before XTTS receives the text.

| Scenario | Original text (verbatim) | Normalized text passed to XTTS |
|---|---|---|
| S1 | Ich bin gerade zwischen zwei Terminen und die Zahlung muss heute noch bearbeitet werden. Die schriftliche Bestätigung reiche ich direkt danach nach. | identical to original (no rule matched) |
| S2 | Ich stehe gerade in der Apotheke und die Bestätigung in der App funktioniert nicht. Bitte helfen Sie mir mit der gestoppten Zahlung. | identical to original (no rule matched) |

Both texts contain no abbreviations, numbers, currency, or percent tokens;
the normalizer returned the input unchanged (verified with the exact
function used by the engine).

## 5. Preprocessing / post-processing (established pipeline)

- Input: no preprocessing beyond normalization (section 4).
- After synthesis the established pipeline runs:
  1. static-noise check (`detect_static_noise`) and duration-anomaly guard
     (see section 6) with automatic retry inside the engine;
  2. `polish_audio`: trim trailing silence (threshold 0.02, pad 0.1 s),
     peak normalization to 0.8 (-2 dB), write 16-bit PCM 24 kHz;
  3. `apply_emotion_audio(neutral)`: no-op for neutral (speed 1.0, pitch 0,
     volume 1.0, no lowpass).

## 6. Duration guard / automatic retry (existing engine behavior)

The established engine automatically re-generates when an output is
flagged:

- Duration anomaly: `seconds > max(len(text)/13.0 + 1.5, 8.0)`.
  For the two scenario texts: S1 threshold = 38.65 s, S2 threshold = 34.96 s.
- Static noise: `detect_static_noise()` (RMS < 0.01, spectral flatness
  > 0.5, or zero-crossing rate > 0.5 on > 0.5 s audio).
- Up to 3 attempts. On a duration retry, the engine itself raises
  temperature to `min(1.05, temperature + 0.08)` and repetition_penalty to
  `max(..., 1.2)`; other retries use the default safe parameter set.
  This is the unchanged, previously established engine behavior — not a
  scenario-specific parameter choice.

Any retry event is recorded in `07_LOGS/xtts_scenario_generation.log` and
`04_RESULTS/xtts_scenario_demo.csv` (initial result, retry event, final
result, reason). No output was manually regenerated or removed.

## 7. Hardware / environment

| Item | Value |
|---|---|
| GPU | NVIDIA RTX A5000 Laptop GPU (CUDA 12.1) |
| Inference device | cuda |
| OS | Windows 11 (PowerShell host) |
| Model loading | once per process, kept in memory (all 6 runs use the already-loaded model) |
| Warmup | one warmup generation (`Hallo. Dies ist ein Test.`) before the measured runs, identical to the established benchmark |
| ASR for content check | faster-whisper `mobiuslabsgmbh/faster-whisper-large-v3-turbo` (cached), beam 5, temperature 0, language de, no VAD |
| Speaker similarity | FunASR CAMPPlus (`campplus_cn_common.bin`, 192-dim, 16 kHz), same implementation/checkpoint as the finalized XTTS metrics |

## 8. Timing methodology (identical to final XTTS benchmark)

- `generation_time_s` = wall-clock interval of the full `engine.synthesize()`
  call (same interval as `scripts/latency_benchmark.py`).
- `output_duration_s` = duration of the final saved WAV (`soundfile`).
- `RTF` = `generation_time_s / output_duration_s`.
- Not included: text entry, playback, decision making, response formulation.
- RTF < 1 is a processing-time ratio, not a claim of real-time
  conversational latency.