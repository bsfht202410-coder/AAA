"""CAMPPlus target-speaker embedding similarity for the 6 scenario outputs.

Identical finalized methodology and reference set as the XTTS metrics
package (tts_chapter7_metrics_FINAL): FunASR CAMPPlus class
(funasr.models.campplus.model.CAMPPlus) + locally cached official
checkpoint campplus_cn_common.bin (192-dim, 16 kHz fbank).
Target set = the same 8 authentic reference clips
(02_SIMILARITY/target_reference_set.csv in the metrics package).

Descriptive only: no threshold, no identity decision, no claim about human
recognition. Absolute values must not be compared numerically with any
other evaluation using a different reference set.
"""

import csv
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
import torch

from funasr.models.campplus.model import CAMPPlus
from funasr.models.campplus.utils import extract_feature
from funasr.utils.load_utils import load_audio_text_image_video

STAGE = Path(r"C:\Users\pcai\AppData\Local\Temp\opencode\scenario_demo")
AUDIO_DIR = STAGE / "05_AUDIO"
METRICS_DIR = STAGE / "02_METRICS"
PROJECT = Path(r"C:\Users\pcai\Desktop\TTStest")

CKPT = Path(
    r"C:\Users\pcai\.cache\huggingface\hub\models--funasr--campplus\snapshots\fb71fe990cbf6031ae6987a2d76fe64f94377b7e\campplus_cn_common.bin"
)

# Same finalized target set as the XTTS metrics package
TARGET_CLIPS = [
    "audio1_chunk_046.wav",
    "audio3_chunk_074.wav",
    "audio3_chunk_026.wav",
    "audio1_chunk_079.wav",
    "audio1_chunk_045.wav",
    "audio2_chunk_058.wav",
    "audio1_chunk_081.wav",
    "audio2_chunk_052.wav",
]

FILES = [
    ("S1", 1), ("S1", 2), ("S1", 3),
    ("S2", 1), ("S2", 2), ("S2", 3),
]


def embed(model, path):
    wav = load_audio_text_image_video(str(path), fs=16000, audio_fs=16000, data_type="sound")
    speech, speech_lengths, speech_times = extract_feature([wav])
    with torch.no_grad():
        e = model.forward(speech.float().cuda())[0].detach().cpu().numpy().reshape(-1)
    e = e / (np.linalg.norm(e) + 1e-12)
    return e


def main():
    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    print("loading CAMPPlus (funasr, campplus_cn_common.bin)")
    model = CAMPPlus()
    sd = torch.load(str(CKPT), map_location="cpu", weights_only=False)
    model.load_state_dict(sd)
    model.eval().cuda()

    ref_dir = PROJECT / "data/audio/reference"
    embs = np.stack([embed(model, ref_dir / c) for c in TARGET_CLIPS])
    centroid = embs.mean(axis=0)
    centroid = centroid / (np.linalg.norm(centroid) + 1e-12)
    loo = []
    for i in range(len(embs)):
        c = embs[np.arange(len(embs)) != i].mean(axis=0)
        c = c / (np.linalg.norm(c) + 1e-12)
        loo.append(float(np.dot(embs[i], c)))
    loo = np.array(loo)
    print(f"target set: n={len(embs)} LOO mean={loo.mean():.4f} "
          f"std={loo.std():.4f} min={loo.min():.4f} max={loo.max():.4f}")

    rows = []
    for sid, run in FILES:
        name = f"{sid}_XTTS_run{run:02d}.wav"
        path = AUDIO_DIR / name
        sim = float(np.dot(embed(model, path), centroid))
        dur = round(sf.info(str(path)).duration, 3)
        rows.append({
            "output_filename": name, "scenario": sid, "run": run,
            "output_duration_s": dur,
            "campplus_similarity": round(sim, 4),
            "reference_set": "same 8-clip target set as finalized XTTS metrics (audio1_chunk_046, audio3_chunk_074, audio3_chunk_026, audio1_chunk_079, audio1_chunk_045, audio2_chunk_058, audio1_chunk_081, audio2_chunk_052)",
        })
        print(f"{name}: sim={sim:.4f} dur={dur}s")

    with open(METRICS_DIR / "xtts_scenario_similarity.csv", "w", newline="",
              encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print("wrote", METRICS_DIR / "xtts_scenario_similarity.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())