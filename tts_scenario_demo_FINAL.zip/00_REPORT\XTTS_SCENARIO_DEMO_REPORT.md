# XTTS Scenario Demo — Final Report

Final scenario-linked technical demonstration, Chapter 7. The fixed XTTS
configuration was tested on two scenario-relevant German utterances for
content preservation, target-speaker embedding similarity, processing time,
and generation stability.

Scope: exactly 6 generations (2 texts x 3 independent runs), fixed final
configuration (see `01_CONFIG/final_xtts_scenario_config.md`), no parameter
tuning, no cherry-picking, no output removed. The recorded scenario audio
(`Desktop/scenario_audio/`) is for the STS systems only and was NOT used as
XTTS input.

## Results at a glance

| run | gen (s) | audio (s) | RTF | WER | CER | CAMPPlus | status |
|---|---|---|---|---|---|---|---|
| S1 run 1 | 3.485 | 8.53 | 0.41 | 0.000 | 0.000 | 0.764 | none |
| S1 run 2 | 11.257 | 4.76 | 2.36 | 0.364 | 0.404 | 0.723 | truncation, missing content, abnormal gen time |
| S1 run 3 | 3.416 | 8.15 | 0.42 | 0.000 | 0.000 | 0.761 | none |
| S2 run 1 | 3.252 | 7.49 | 0.43 | 0.000 | 0.000 | 0.773 | none |
| S2 run 2 | 3.458 | 8.70 | 0.40 | 0.000 | 0.000 | 0.766 | none |
| S2 run 3 | 2.866 | 7.04 | 0.41 | 0.000 | 0.000 | 0.747 | none |

## Answers

1. **Did all six planned generations complete?** Yes. All six WAVs exist
   (`05_AUDIO/`), none crashed, none was regenerated or replaced.

2. **How reliably was the exact scenario text preserved?** 5 of 6 outputs
   are verbatim-perfect (WER = CER = 0.000). S1 run 2 is truncated: the ASR
   transcript ends after "…bearbeitet werden." and the entire second
   sentence ("Die schriftliche Bestätigung reiche ich direkt danach nach.")
   is missing (8 of 22 words deleted, WER 0.364, CER 0.404). No inserted or
   substituted words occurred in any output.

3. **What CAMPPlus similarity was observed?** S1: 0.723–0.764 (mean 0.749);
   S2: 0.747–0.773 (mean 0.762). Target set leave-one-out self-similarity:
   0.955 ± 0.021 (range 0.902–0.973, identical to the finalized XTTS
   metrics package). All outputs remain below the worst within-speaker
   value; descriptive only — no threshold, no identity decision.

4. **How stable were results across the three runs of each scenario?**
   S2: fully stable (3/3 verbatim, RTF 0.397–0.434). S1: 2/3 verbatim; run 2
   deviates (truncated output, RTF 2.36, ~4.8 s audio vs. ~8.3 s siblings).
   No run-to-run drift in speaker similarity (S1 range 0.04, S2 range 0.03).

5. **What generation times and RTFs were observed?** S1: 3.416–11.257 s
   (RTF 0.41–2.36); S2: 2.866–3.458 s (RTF 0.397–0.434). Model loaded once
   (21.1 s, not counted), warmup 2.5 s (not counted); all six runs used the
   already-loaded model. RTF is a processing-time ratio, not a
   conversational-latency claim.

6. **Were any loops, repetitions, truncations, or abnormal durations
   observed?** One truncation: S1 run 2 (missing second sentence; no
   duration-guard trigger because 4.76 s is not an abnormally *long*
   output). No looping, no repetition, no insertion artifacts, no abnormal
   long duration, no static-noise guard event, no crash in any of the six
   runs.

7. **Does the evidence demonstrate human deception success?** NO. No human
   listening experiment was performed; CAMPPlus similarity and ASR metrics
   cannot demonstrate perceptual identity or deception.

8. **Does the evidence demonstrate successful emotional/authority
   performance?** NO. That requires a separate perceptual evaluation. This
   package evaluated only content preservation, embedding similarity,
   timing, and stability.

9. **What narrow technical conclusion can legitimately be drawn?** The
   fixed XTTS configuration was tested on two scenario-relevant German
   utterances for content preservation, target-speaker embedding
   similarity, processing time, and generation stability. Under the fixed
   configuration: 5/6 outputs preserved the exact text (WER 0.0) and all
   outputs matched the established voice-embedding profile of this
   configuration (CAMPPlus 0.72–0.77 vs. target LOO 0.90–0.97); 5/6 runs
   completed at RTF 0.40–0.43 with model already loaded; 1/6 runs
   truncated the second sentence (S1 run 2), which is an observable
   stability limitation of the fixed configuration.

## Files

- `00_REPORT/XTTS_SCENARIO_DEMO_REPORT.md` (this file)
- `01_CONFIG/final_xtts_scenario_config.md` — locked configuration
- `02_METRICS/xtts_scenario_content.csv`, `xtts_scenario_similarity.csv`
- `03_FAILURES/xtts_scenario_failures.csv`
- `04_RESULTS/xtts_scenario_demo.csv` — combined table
- `05_AUDIO/` — the six generated WAVs
- `06_SCRIPTS/` — generation, content-metrics, similarity-metrics, table
  builder (reproducibility)
- `07_LOGS/xtts_scenario_generation.log`, `timing_records.json`

Environment: TTS 0.22.0, torch 2.5.1+cu121, NVIDIA RTX A5000 Laptop GPU;
ASR: faster-whisper large-v3-turbo (beam 5, temperature 0, de);
similarity: FunASR CAMPPlus `campplus_cn_common.bin`.